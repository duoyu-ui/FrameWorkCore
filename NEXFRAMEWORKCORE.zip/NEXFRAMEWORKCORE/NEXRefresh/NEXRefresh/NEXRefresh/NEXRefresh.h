//
//  NEXRefresh.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_REFRESH_
#define _NEX_REFRESH_

#if __has_include(<NEXRefresh/NEXRefresh.h>)

FOUNDATION_EXPORT double NEXRefreshVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXRefreshVersionString[];

#import <NEXRefresh/NEXRefreshHeader.h>
#import <NEXRefresh/NEXRefreshWaveHeader.h>
#import <NEXRefresh/NEXRefreshCircleHeader.h>
#import <NEXRefresh/NEXRefreshFooter.h>
#import <NEXRefresh/NEXRefreshCircleFooter.h>
#import <NEXRefresh/NEXRefreshAutoWaveFooter.h>
#import <NEXRefresh/NEXWaveActivityIndicatorView.h>
#import <NEXRefresh/NEXCircleActivityIndicatorView.h>

#else

#import "NEXRefreshHeader.h"
#import "NEXRefreshWaveHeader.h"
#import "NEXRefreshCircleHeader.h"
#import "NEXRefreshFooter.h"
#import "NEXRefreshCircleFooter.h"
#import "NEXRefreshAutoWaveFooter.h"
#import "NEXWaveActivityIndicatorView.h"
#import "NEXCircleActivityIndicatorView.h"

#endif /* __has_include */

#endif /* _NEX_REFRESH_ */




