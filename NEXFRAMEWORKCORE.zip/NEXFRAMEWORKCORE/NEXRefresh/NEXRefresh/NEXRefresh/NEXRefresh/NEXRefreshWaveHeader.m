//
//  NEXRefreshWaveHeader.m
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXRefreshWaveHeader.h"
#import "NEXWaveActivityIndicatorView.h"

@interface NEXRefreshWaveHeader()
@property (nonatomic, weak) NEXWaveActivityIndicatorView *loadingView;
@end

@implementation NEXRefreshWaveHeader

#pragma mark - 懒加载子控件
- (NEXWaveActivityIndicatorView *)loadingView
{
    if (!_loadingView) {
        CGRect loadingViewFrame = CGRectMake(0, 0, 75, 20);
        NEXWaveActivityIndicatorView *loadingView =[[NEXWaveActivityIndicatorView alloc] initWithFrame:loadingViewFrame
                                                                                             grayImage:[UIImage imageNamed:@"grayLogo"]
                                                                                            frontImage:[UIImage imageNamed:@"frontLogo"]];
        [self addSubview:_loadingView = loadingView];
    }
    return _loadingView;
}

#pragma mark - 重写父类的方法
#pragma mark 在这里做一些初始化配置（比如添加子控件）
- (void)prepare
{
    [super prepare];
    
    // 设置控件的高度
    self.mj_h = 60;
}

#pragma mark 在这里设置子控件的位置和尺寸
- (void)placeSubviews
{
    [super placeSubviews];
    
    // 中心点
    CGFloat arrowCenterX = self.mj_w * 0.5;
    CGFloat arrowCenterY = self.mj_h * 0.5;
    
    // 圈圈
    if (!self.stateLabel.hidden) {
        // LOGO
        self.loadingView.center = CGPointMake(arrowCenterX, arrowCenterY - 8);
        // 状态
        self.stateLabel.center = CGPointMake(arrowCenterX, arrowCenterY + 15);
    } else {
        // LOGO
        self.loadingView.center = CGPointMake(arrowCenterX, arrowCenterY + 8);
    }
    
}

#pragma mark 监听scrollView的contentOffset改变
- (void)scrollViewContentOffsetDidChange:(NSDictionary *)change
{
    [super scrollViewContentOffsetDidChange:change];
}

#pragma mark 监听scrollView的contentSize改变
- (void)scrollViewContentSizeDidChange:(NSDictionary *)change
{
    [super scrollViewContentSizeDidChange:change];
}

#pragma mark 监听scrollView的拖拽状态改变
- (void)scrollViewPanStateDidChange:(NSDictionary *)change
{
    [super scrollViewPanStateDidChange:change];
}

#pragma mark 监听控件的刷新状态
- (void)setState:(MJRefreshState)state
{
    MJRefreshCheckState
    
    // 根据状态做事情
    if (state == MJRefreshStateIdle) {
        if (oldState == MJRefreshStateRefreshing) {
            [UIView animateWithDuration:MJRefreshSlowAnimationDuration animations:^{
                self.loadingView.alpha = 0.0;
            } completion:^(BOOL finished) {
                // 如果执行完动画发现不是idle状态，就直接返回，进入其他状态
                if (self.state != MJRefreshStateIdle) return;
                
                self.loadingView.alpha = 1.0;
                [self.loadingView stopAnimating];
            }];
        } else {
            [self.loadingView stopAnimating];
        }
    } else if (state == MJRefreshStatePulling) {
        [self.loadingView stopAnimating];
    } else if (state == MJRefreshStateRefreshing) {
        self.loadingView.alpha = 1.0; // 防止refreshing -> idle的动画完毕动作没有被执行
        [self.loadingView startAnimating];
    }
}


@end

