//
//  NEXRefreshCircleHeader.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXRefreshHeader.h"

@interface NEXRefreshCircleHeader : NEXRefreshHeader

@property (nonatomic, weak) UIColor *frontLineColor;
@property (nonatomic, weak) UIColor *backLineColor;

@end
