//
//  NEXCircleActivityIndicatorView.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NEXCircleActivityIndicatorView : UIView

@property (nonatomic, assign) CGFloat anglePercent;
@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, strong) UIColor *frontLineColor;
@property (nonatomic, strong) UIColor *backLineColor;
@property (nonatomic, readonly) BOOL isAnimating;

- (void)startAnimating;
- (void)stopAnimating;

@end
