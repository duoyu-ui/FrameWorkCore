//
//  NEXRefreshHeader.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "MJRefreshStateHeader.h"

#pragma mark 上拉刷新提示信息
UIKIT_EXTERN CGFloat const NEXRefreshAutoFooterFontSize;
UIKIT_EXTERN NSString *const NEXRefreshAutoFooterIdleText;
UIKIT_EXTERN NSString *const NEXRefreshAutoFooterRefreshingText;
UIKIT_EXTERN NSString *const NEXRefreshAutoFooterNoMoreDataText;

@interface NEXRefreshHeader : MJRefreshStateHeader

@end
