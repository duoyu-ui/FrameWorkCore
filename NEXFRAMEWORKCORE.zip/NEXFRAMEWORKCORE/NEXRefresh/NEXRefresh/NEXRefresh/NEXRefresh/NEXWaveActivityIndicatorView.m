//
//  NEXWaveActivityIndicatorView.m
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXWaveActivityIndicatorView.h"

@interface NEXWaveActivityIndicatorView ()

@property (nonatomic) CGFloat waveWidth;
@property (nonatomic) CGFloat waveHeight;
@property (nonatomic) CGFloat density;
@property (nonatomic) CGFloat waveMid;
@property (nonatomic) CGFloat maxAmplitude;

@property (nonatomic) CGFloat phaseShift;
@property (nonatomic) CGFloat phase;
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (strong, nonatomic) CAShapeLayer *waveLayer;

@property (weak, nonatomic) UIImageView *grayLogo;
@property (weak, nonatomic) UIImageView *frontLogo;

@end


@implementation NEXWaveActivityIndicatorView


- (instancetype)initWithFrame:(CGRect)frame grayImage:(UIImage *)grayImage frontImage:(UIImage *)frontImage
{
    _frontLogoImage = frontImage;
    _grayLogoImage = grayImage;
    return [self initWithFrame:frame];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)commonInit
{
    CALayer *mask = [CALayer layer];
    mask.frame = self.bounds;
    self.waveLayer = [CAShapeLayer layer];
    self.waveLayer.fillColor = [[UIColor greenColor] CGColor];
    self.waveLayer.frame = CGRectMake(0, self.bounds.size.height-5, self.bounds.size.width, self.bounds.size.height);
    
    self.waveHeight = CGRectGetHeight(self.bounds)*0.5;
    self.waveWidth  = CGRectGetWidth(self.bounds);
    self.density = 1.0f;
    self.frequency = 0.6f;
    self.phaseShift = -0.25f;
    
    // 图片
    UIImageView *grayLogo = [[UIImageView alloc] initWithFrame:self.bounds];
    UIImageView *frontLogo = [[UIImageView alloc] initWithFrame:self.bounds];
    grayLogo.image = self.grayLogoImage;
    frontLogo.image = self.frontLogoImage;
    [self addSubview:grayLogo];
    [self addSubview:frontLogo];
    
    self.grayLogo = grayLogo;
    self.frontLogo = frontLogo;
    
    //mask
    [mask addSublayer:self.waveLayer];
    self.frontLogo.layer.mask = mask;
}


- (void)startAnimating
{
    
    [self.displayLink invalidate];
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(update)];
    [self.displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
    
    CGPoint position = self.waveLayer.position;
    position.y = position.y - self.bounds.size.height-5;
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"position"];
    animation.fromValue = [NSValue valueWithCGPoint:self.waveLayer.position];
    animation.toValue = [NSValue valueWithCGPoint:position];
    animation.duration = 5.0;
    animation.repeatCount = HUGE_VALF;
    animation.removedOnCompletion = NO;
    [self.waveLayer addAnimation:animation forKey:nil];
}


- (void)stopAnimating
{
    [self.displayLink invalidate];
    [self.waveLayer removeAllAnimations];
    self.waveLayer.path = nil;
}


// 波浪绘制
- (void)update
{
    self.phase += self.phaseShift;
    self.waveMid = self.waveWidth / 2.0f;
    self.maxAmplitude = self.waveHeight - 4.0f;
    
    UIGraphicsBeginImageContext(self.frame.size);
    UIBezierPath *wavePath = [UIBezierPath bezierPath];
    CGFloat endX = 0;
    for (CGFloat x = 0; x < self.waveWidth + self.density; x += self.density) {
        endX=x;
        CGFloat scaling = -pow(x / self.waveMid  - 1, 2) + 1;//波浪中间变大
        CGFloat y = scaling * self.maxAmplitude  * sinf(2 * M_PI *(x / 50) * self.frequency + self.phase) + (self.waveHeight * 0.5);
        if (x == 0) {
            [wavePath moveToPoint:CGPointMake(x, y)];
        } else {
            [wavePath addLineToPoint:CGPointMake(x, y)];
        }
    }
    CGFloat endY = CGRectGetHeight(self.bounds)+15;
    [wavePath addLineToPoint:CGPointMake(endX, endY)];
    [wavePath addLineToPoint:CGPointMake(0, endY)];
    [wavePath addLineToPoint:CGPointMake(0, 5)];
    
    self.waveLayer.path = [wavePath CGPath];
    UIGraphicsEndImageContext();
}


#pragma mark - getter/setter
- (void)setGrayLogoImage:(UIImage *)grayLogoImage
{
    _grayLogoImage = grayLogoImage;
    self.grayLogo.image = grayLogoImage;
}


- (void)setFrontLogoImage:(UIImage *)frontLogoImage
{
    _frontLogoImage = frontLogoImage;
    self.frontLogo.image = frontLogoImage;
}

@end

