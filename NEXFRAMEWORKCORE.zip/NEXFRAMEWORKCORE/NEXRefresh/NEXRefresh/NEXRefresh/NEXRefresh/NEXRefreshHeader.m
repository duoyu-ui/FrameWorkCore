//
//  NEXRefreshHeader.m
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXRefreshHeader.h"

@implementation NEXRefreshHeader

#pragma mark MJRefresh上拉刷新提示信息
CGFloat const NEXRefreshAutoFooterFontSize = 13.0;
NSString *const NEXRefreshAutoFooterIdleText = @"点击或上拉加载更多";
NSString *const NEXRefreshAutoFooterRefreshingText = @"正在加载更多的数据...";
NSString *const NEXRefreshAutoFooterNoMoreDataText = @"已经全部加载完毕";

@end
