//
//  NEXWaveActivityIndicatorView.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NEXWaveActivityIndicatorView : UIView

@property (nonatomic) CGFloat frequency; // 波浪频率
@property (strong, nonatomic) UIImage *grayLogoImage;
@property (strong, nonatomic) UIImage *frontLogoImage;


/**
 *  初始化
 *
 *  @param grayImage 底部灰色图片
 *  @param frontImage 需要显示出来的图片
 *
 */
- (instancetype)initWithFrame:(CGRect)frame grayImage:(UIImage *)grayImage frontImage:(UIImage *)frontImage;

- (void)startAnimating;

- (void)stopAnimating;

@end
