//
//  NEXRefreshAppDelegate.m
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXRefreshAppDelegate.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

@implementation NEXRefreshAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NEXLog(@"刷新模块 -> 加载刷新模块");
    
    return YES;
}

@end

