//
//  NEXRefreshAppDelegate.h
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#if __has_include(<NEXModuleManager/NEXModuleAppManager.h>)
#import <NEXModuleManager/NEXModuleAppManager.h>
#else
#import "NEXModuleAppManager.h"
#endif

@interface NEXRefreshAppDelegate : NSObject  <NEXModuleApplicationDelegate>

@end
