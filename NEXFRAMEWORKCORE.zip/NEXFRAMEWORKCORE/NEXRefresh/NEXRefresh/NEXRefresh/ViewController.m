//
//  ViewController.m
//  NEXRefresh
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "ViewController.h"
#import "NEXRefresh.h"

@interface ViewController ()

@end


@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"刷新模块";
    
}


@end

