//
//  NEXStringMacro.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_STRING_MACRO_H_
#define _NEX_STRING_MACRO_H_


#pragma mark - 导航栏按钮标题 - 返回/默认
#define STR_NAVIGATION_BAR_BUTTON_TITLE_EMPTY                                        @""
#define STR_NAVIGATION_BAR_BUTTON_TITLE_RETURN_BACK                                  @"返回"


#endif /* _NEX_STRING_MACRO_H_ */
