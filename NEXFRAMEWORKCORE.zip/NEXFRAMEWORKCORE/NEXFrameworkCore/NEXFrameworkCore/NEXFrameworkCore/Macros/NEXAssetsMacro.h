
//
//  NEXAssetsMacro.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_ASSETS_MACRO_H_
#define _NEX_ASSETS_MACRO_H_


#pragma mark -
#pragma mark 图标：导航栏按钮
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_DEF                   @"NEXFrameworkResources.bundle/icon_navbar_btn_back_arrow_white"
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_WHITE                 @"NEXFrameworkResources.bundle/icon_navbar_btn_back_arrow_white"
#define ICON_NAVIGATION_BAR_BUTTON_BACK_ARROW_BLACK                 @"NEXFrameworkResources.bundle/icon_navbar_btn_back_arrow_black"
#define ICON_NAVIGATION_BAR_BUTTON_CLOSE_WHITE                      @"NEXFrameworkResources.bundle/icon_navbar_btn_close_white"
#define ICON_NAVIGATION_BAR_BUTTON_CLOSE_BLACK                      @"NEXFrameworkResources.bundle/icon_navbar_btn_close_black"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_DEF                         @"NEXFrameworkResources.bundle/icon_navbar_btn_more_point_white"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_WHITE                       @"NEXFrameworkResources.bundle/icon_navbar_btn_more_point_white"
#define ICON_NAVIGATION_BAR_BUTTON_MORE_BLACK                       @"NEXFrameworkResources.bundle/icon_navbar_btn_more_point_black"


#pragma mark -
#pragma mark 图标：空白占位符
#define ICON_SCROLLVIEW_EMPTY_DATASET_RESULT                        @"NEXFrameworkResources.bundle/icon_empty_dataset_result"


#endif /* _NEX_ASSETS_MACRO_H_ */



