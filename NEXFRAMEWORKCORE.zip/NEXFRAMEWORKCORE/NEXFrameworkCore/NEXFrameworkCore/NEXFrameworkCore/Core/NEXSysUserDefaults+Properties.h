//
//  NEXSysUserDefaults+Properties.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//


#if __has_include(<NEXUserDefaults/NEXUserDefaults.h>)
#import <NEXUserDefaults/NEXUserDefaults.h>
#else
#import "NEXUserDefaults.h"
#endif


@interface NEXSysUserDefaults (Properties)

@property (nonatomic, weak) NSString *token;               // 系统Token
@property (nonatomic, weak) NSString *userId;              // 用户标识
@property (nonatomic, weak) NSString *userName;            // 用户名称
@property (nonatomic, weak) NSString *nickName;            // 用户名称
@property (nonatomic, weak) NSString *appversion;          // 系统版本
@property (nonatomic, assign) BOOL loginStatus;            // 登录状态

@property (nonatomic, weak) NSString *siteId;              // 站点标识
@property (nonatomic, weak) NSString *agentId;             // 代理标识
@property (nonatomic, weak) NSString *deviceIp;            // 设备IP地址

@end



