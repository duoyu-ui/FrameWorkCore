//
//  ViewController.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXBaseCoreViewController.h"

@interface ViewController : NEXBaseCoreViewController


@end

