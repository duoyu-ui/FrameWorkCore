//
//  NSString+ContainString.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/3/31.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ContainString)

- (BOOL)hasContainString:(NSString*)subString;

@end
