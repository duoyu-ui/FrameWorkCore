//
//  NEXFrameworkCore.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//


#ifndef _NEX_FRAMEWORK_CORE_
#define _NEX_FRAMEWORK_CORE_


#if __has_include(<NEXFrameworkCore/NEXFrameworkCore.h>)

FOUNDATION_EXPORT double NEXFrameworkCoreVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXFrameworkCoreVersionString[];

// Core
#import <NEXFrameworkCore/NEXSysCore.h>
#import <NEXFrameworkCore/NEXSysConst.h>
#import <NEXFrameworkCore/NEXSysUserDefaults+Properties.h>
// Utils
#import <NEXFrameworkCore/NEXSysUtil.h>
#import <NEXFrameworkCore/NEXAppUtil.h>
#import <NEXFrameworkCore/NEXDateUtil.h>
#import <NEXFrameworkCore/NEXAutosizingUtil.h>
#import <NEXFrameworkCore/NEXStringMathsUtil.h>
// UIKit
#import <NEXFrameworkCore/NEXTabBarController.h>
#import <NEXFrameworkCore/NEXNavigationController.h>
#import <NEXFrameworkCore/NEXNavBarViewController.h>
#import <NEXFrameworkCore/NEXNetworkViewController.h>
#import <NEXFrameworkCore/NEXBaseCoreViewController.h>
#import <NEXFrameworkCore/NEXBaseCommonViewController.h>
#import <NEXFrameworkCore/NEXBaseWKWebViewController.h>
#import <NEXFrameworkCore/NEXTableRefreshViewController.h>
#import <NEXFrameworkCore/NEXTableRefreshViewController+EmptyDataSet.h>
#import <NEXFrameworkCore/NEXTabBarController+InterfaceOrientation.h>
#import <NEXFrameworkCore/NEXNavigationController+InterfaceOrientation.h>
// Macros
#import <NEXFrameworkCore/NEXStringMacro.h>
#import <NEXFrameworkCore/NEXAssetsMacro.h>
#import <NEXFrameworkCore/NEXSysCoreMacro.h>
// Vender
#import <NEXFrameworkCore/CMPopTipView.h>
#import <NEXFrameworkCore/YHSDropDownMenu.h>
#import <NEXFrameworkCore/WebViewJavascriptBridge.h>
#import <NEXFrameworkCore/WebViewJavascriptBridge_JS.h>
#import <NEXFrameworkCore/WebViewJavascriptBridgeBase.h>
#import <NEXFrameworkCore/WKWebViewJavascriptBridge.h>
#import <NEXFrameworkCore/NSObject+SXRuntime.h>
#import <NEXFrameworkCore/UIBarButtonItem+SXCreate.h>
#import <NEXFrameworkCore/UINavigation+SXFixSpace.h>
#import <NEXFrameworkCore/UINavigationController+FDFullscreenPopGesture.h>
#import <NEXFrameworkCore/TPKeyboardAvoidingScrollView.h>
#import <NEXFrameworkCore/TPKeyboardAvoidingTableView.h>
#import <NEXFrameworkCore/TPKeyboardAvoidingCollectionView.h>
#import <NEXFrameworkCore/UIScrollView+TPKeyboardAvoidingAdditions.h>
#import <NEXFrameworkCore/JCAlertController.h>
// Categories
#import <NEXFrameworkCore/NEXCategories.h>
// AppDelegate
#import <NEXFrameworkCore/NEXFrameworkCoreAppDelegate.h>

#else

// Core
#import "NEXSysCore.h"
#import "NEXSysConst.h"
#import "NEXSysUserDefaults.h"
#import "NEXSysUserDefaults+Properties.h"
// Utils
#import "NEXSysUtil.h"
#import "NEXAppUtil.h"
#import "NEXDateUtil.h"
#import "NEXAutosizingUtil.h"
#import "NEXStringMathsUtil.h"
// UIKit
#import "NEXTabBarController.h"
#import "NEXNavigationController.h"
#import "NEXNavBarViewController.h"
#import "NEXNetworkViewController.h"
#import "NEXBaseCoreViewController.h"
#import "NEXBaseCommonViewController.h"
#import "NEXBaseWKWebViewController.h"
#import "NEXTableRefreshViewController.h"
#import "NEXTableRefreshViewController+EmptyDataSet.h"
#import "NEXTabBarController+InterfaceOrientation.h"
#import "NEXNavigationController+InterfaceOrientation.h"
// Macros
#import "NEXStringMacro.h"
#import "NEXAssetsMacro.h"
#import "NEXSysCoreMacro.h"
// Vender
#import "CMPopTipView.h"
#import "YHSDropDownMenu.h"
#import "WebViewJavascriptBridge.h"
#import "WebViewJavascriptBridge_JS.h"
#import "WebViewJavascriptBridgeBase.h"
#import "WKWebViewJavascriptBridge.h"
#import "NSObject+SXRuntime.h"
#import "UIBarButtonItem+SXCreate.h"
#import "UINavigation+SXFixSpace.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "TPKeyboardAvoidingTableView.h"
#import "TPKeyboardAvoidingCollectionView.h"
#import "UIScrollView+TPKeyboardAvoidingAdditions.h"
#import "JCAlertController.h"
// Categories
#import "NEXCategories.h"
// AppDelegate
#import "NEXFrameworkCoreAppDelegate.h"

#endif /* __has_include */


#endif /* _NEX_FRAMEWORK_CORE_ */




