//
//  NEXDateUtil.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NEXDateUtil : NSObject



#pragma mark -
#pragma mark 当前时间格式化, 例:YYYY-MM-dd-EEEE-HH:mm:ss
+ (NSString *)getCurrentDateWithDateFormate:(NSString *)formate;

#pragma mark 任意NSDate格式化
+ (NSString *)dateFormattingWithDate:(NSDate *)date toFormate:(NSString *)formate;

#pragma mark 任意NSDate格式化字符串
+ (NSString *)dateFormattingWithDateString:(NSString *)dateString dateFormate:(NSString *)dateFormate toFormate:(NSString *)toFormate;

#pragma mark 根据组件获取日期字符串
+ (NSString *)dateFormattingWithDateComponents:(NSDateComponents *)dateComponents toFormate:(NSString *)formate;

#pragma mark 根据组件获取时间
+ (NSDate *)getDateWithDateComponents:(NSDateComponents *)dateComponents;

#pragma mark 获取周的第一天
+ (NSDate *)getFirstDateOfWeekFromDate:(NSDate *)date;

#pragma mark 获取周的最后一天
+ (NSDate *)getLastDateOfWeekFromDate:(NSDate *)date;

#pragma mark 获取月的第一天
+ (NSDate *)getFirstDateOfMonthFromDate:(NSDate *)date;

#pragma mark 获取月的最后一天
+ (NSDate *)getLastDateOfMonthFromDate:(NSDate *)date;

#pragma mark 获取00点时间
+ (NSDate *)returnDate00Clock:(NSDate *)date;

#pragma mark 获取当天24点时间
+ (NSDate *)returnDate24Clock:(NSDate *)date;

#pragma mark 获取当天00点时间
+ (NSDate *)returnToDay00Clock;

#pragma mark 获取当天24点时间
+ (NSDate *)returnToDay24Clock;

#pragma mark 获取当前秒数
+ (long long)getCurrentDateSecond;

#pragma mark NSDate转秒
+ (long long)dateTosecond:(NSDate *)date;

#pragma mark 秒转NSDate
+ (NSDate *)secondToDate:(long long)second;

#pragma mark 朋友圈/聊天 时间显示样式
+ (NSString *)dateDisplayResult:(long long)secondCount;


@end
