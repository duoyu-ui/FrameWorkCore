//
//  NEXDateUtil.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXDateUtil.h"

#if __has_include(<DateTools/DateTools.h>)
#import <DateTools/DateTools.h>
#else
#import "DateTools.h"
#endif


@implementation NEXDateUtil

#pragma mark -
#pragma mark 当前时间格式化, 例:YYYY-MM-dd-EEEE-HH:mm:ss
+ (NSString *)getCurrentDateWithDateFormate:(NSString *)formate
{
    NSDate *now = [NSDate date];
    return [self dateFormattingWithDate:now toFormate:formate];
}

#pragma mark 任意NSDate格式化
+ (NSString *)dateFormattingWithDate:(NSDate *)date toFormate:(NSString *)formate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formate];
    return [formatter stringFromDate:date];
}

#pragma mark 任意NSDate格式化字符串
+ (NSString *)dateFormattingWithDateString:(NSString *)dateString dateFormate:(NSString *)dateFormate toFormate:(NSString *)toFormate
{
    NSDate *date = [NSDate dateWithString:dateString formatString:dateFormate];
    return [NEXDateUtil dateFormattingWithDate:date toFormate:toFormate];
}

#pragma mark 根据组件获取日期字符串
+ (NSString *)dateFormattingWithDateComponents:(NSDateComponents *)dateComponents toFormate:(NSString *)formate
{
    NSDate *date = [NEXDateUtil getDateWithDateComponents:dateComponents];
    return [NEXDateUtil dateFormattingWithDate:date toFormate:formate];
}

#pragma mark 根据组件获取时间
+ (NSDate *)getDateWithDateComponents:(NSDateComponents *)dateComponents
{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    return [gregorian dateFromComponents:dateComponents];
#pragma clang diagnostic pop
}

#pragma mark 获取00点时间
+ (NSDate *)returnDate00Clock:(NSDate *)date
{
    NSCalendar *calender = [NSCalendar currentCalendar];
    NSUInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    NSDateComponents *dateComponent = [calender components:unitFlags fromDate:date];
    int hour = (int)[dateComponent hour];
    int minute = (int)[dateComponent minute];
    int second = (int)[dateComponent second];
    // 当前时分秒:hour,minute,second
    // 返回当前时间(hour * 3600 + minute * 60 + second)之前的时间,即为今天凌晨0点
    NSDate *nowDay = [NSDate dateWithTimeInterval: - (hour * 3600 + minute * 60 + second) sinceDate:date];
    long long inter = [nowDay timeIntervalSince1970] * 1000;
    NSDate *newDate = [NSDate dateWithTimeIntervalSince1970:inter / 1000];
    return newDate;
}

#pragma mark 获取24点时间
+ (NSDate *)returnDate24Clock:(NSDate *)date
{
    NSCalendar *calender = [NSCalendar currentCalendar];
    NSUInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    NSDateComponents *dateComponent = [calender components:unitFlags fromDate:date];
    int hour = (int)[dateComponent hour];
    int minute = (int)[dateComponent minute];
    int second = (int)[dateComponent second];
    // 一天是60分钟 * 60秒 * 24小时 = 86400秒
    NSDate *nextDay = [NSDate dateWithTimeInterval: - (hour * 3600 + minute * 60 + second) + 86400 - 1 sinceDate:date];
    return nextDay;
}

#pragma mark 获取周的第一天
+ (NSDate *)getFirstDateOfWeekFromDate:(NSDate *)date
{
    NSInteger day = date.day;
    NSInteger dayofweek = date.weekday;
    return [NSDate dateWithYear:date.year month:date.month day:(day - (dayofweek - 2))];
}

#pragma mark 获取周的最后一天
+ (NSDate *)getLastDateOfWeekFromDate:(NSDate *)date
{
    NSInteger day = date.day;
    NSInteger dayofweek = date.weekday;
    return [NSDate dateWithYear:date.year month:date.month day:(day +(7-dayofweek)+1)];
}

#pragma mark 获取月的第一天
+ (NSDate *)getFirstDateOfMonthFromDate:(NSDate *)date
{
    return [NSDate dateWithYear:date.year month:date.month day:1];
}

#pragma mark 获取月的最后一天
+ (NSDate *)getLastDateOfMonthFromDate:(NSDate *)date
{
    return [NSDate dateWithYear:date.year month:date.month day:date.daysInMonth];
}


#pragma mark 获取当天0点时间
+ (NSDate *)returnToDay00Clock
{
    return [NEXDateUtil returnDate00Clock:[NSDate date]];
}

#pragma mark 获取当天24点时间
+ (NSDate *)returnToDay24Clock
{
    return [NEXDateUtil returnDate24Clock:[NSDate date]];
}

#pragma mark 获取当前秒数
+ (long long)getCurrentDateSecond
{
    return [[NSDate date] timeIntervalSince1970];
}

#pragma mark NSDate转秒
+ (long long)dateTosecond:(NSDate *)date
{
    return [date timeIntervalSince1970];
}

#pragma mark 秒转NSDate
+ (NSDate *)secondToDate:(long long)second
{
    return [NSDate dateWithTimeIntervalSince1970:second];
}

#pragma mark 朋友圈/聊天 时间显示样式
+ (NSString *)dateDisplayResult:(long long)secondCount
{
    NSDate *date = [self secondToDate:secondCount];
    NSCalendar *calender = [NSCalendar currentCalendar];
    // 判断是否是今天
    if ([calender isDateInToday:date]) {
        
        long long dateSecondCount = [[NSDate date] timeIntervalSinceDate:date];
        if (dateSecondCount < 60) {
            return @"刚刚";
        }
        if (dateSecondCount < (60 * 60)) {
            return [NSString stringWithFormat:@"%d分钟前",(int)(dateSecondCount / 60)];
        }
        return [NSString stringWithFormat:@"%d小时前",(int)(dateSecondCount / (60 * 60))];
    }
    
    // 判断是否是昨天
    NSString *formatterString = @" HH:mm";
    if ([calender isDateInYesterday:date]) {
        formatterString = [@"昨天" stringByAppendingString:formatterString];
    } else {
        // 判断是否是一年内
        formatterString = [@"MM-dd" stringByAppendingString:formatterString];
        // 判断是否值一年之前
        NSDateComponents *component = [calender components:NSCalendarUnitYear fromDate:date toDate:[NSDate date] options:NSCalendarWrapComponents];
        
        if (component.year >= 1) {
            formatterString = [@"YYYY-" stringByAppendingString:formatterString];
        }
    }
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatterString];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en"];
    return [formatter stringFromDate:date];
}


@end
