//
//  NEXSysUtil.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/30.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>


#pragma mark - 投注余额格式
#define NEX_MONEY_FORMATTER_WITH_POINT_00_FORMAT_STRING               @"###,##0;"
#define NEX_MONEY_FORMATTER_WITH_POINT_01_FORMAT_STRING               @"###,##0.0;"
#define NEX_MONEY_FORMATTER_WITH_POINT_02_FORMAT_STRING               @"###,##0.00;"


@interface NEXSysUtil : NSObject


#pragma mark -
#pragma mark 验证对象是否为空（数组、字典、字符串）
+ (BOOL)validateObjectIsNull:(id)obj;
#pragma mark 验证字符串是否为空
+ (BOOL)validateStringEmpty:(NSString *)value;


#pragma mark -
#pragma mark 删除字符串两端的空格与回车
+ (NSString *)stringByTrimmingWhitespaceAndNewline:(NSString *)value;

#pragma mark -
#pragma mark 金额保留N位小数，且不四舍五入
+ (NSString *)stringNotRoundNumberString:(NSString *)numberString afterPoint:(NSInteger)position;
#pragma mark 格式化金钱数据，且不四舍五入
+ (NSString *)stringToDealMoneyString:(NSString *)moneyString formatter:(NSString *)format maximumFractionDigits:(NSInteger)maximumDigits;


#pragma mark -
#pragma mark 获取所有字体名称列表
+ (NSArray<NSString *> *)getAllFontFamilyNames;



@end



