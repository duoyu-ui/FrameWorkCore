//
//  NEXAppUtil.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/30.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NEXAppUtil : NSObject


#pragma mark -
#pragma mark 获取根视图控制器
+ (UIViewController *)getAppRootViewController;
#pragma mark 获取根顶部控制器
+ (UIViewController*)getTopViewController;


#pragma mark -
#pragma mark 获取应用版本信息
+ (NSString *)getAppVersion;


@end

