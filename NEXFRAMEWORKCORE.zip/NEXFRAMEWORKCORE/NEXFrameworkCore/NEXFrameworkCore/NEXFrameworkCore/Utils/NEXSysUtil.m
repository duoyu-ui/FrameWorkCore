//
//  NEXSysUtil.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/30.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXSysUtil.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

@implementation NEXSysUtil

#pragma mark -
#pragma mark 验证对象是否为空（数组、字典、字符串）
+ (BOOL)validateObjectIsNull:(id)obj
{
    if (nil == obj || obj == [NSNull null]) {
        return YES;
    }
    
    // 字典
    if ([obj isKindOfClass:[NSDictionary class]]) {
        
        if([obj isKindOfClass:[NSNull class]]) {
            return YES;
        }
    }
    // 数组
    else if ([obj isKindOfClass:[NSArray class]]) {
        
        if([obj isKindOfClass:[NSNull class]]) {
            return YES;
        }
    }
    // 字符串
    else if ([obj isKindOfClass:[NSString class]]) {
        
        return [NEXSysUtil validateStringEmpty:obj];
    }
    
    return NO;
}

#pragma mark 验证字符串是否为空
+ (BOOL)validateStringEmpty:(NSString *)value
{
    if (nil == value
        || [@"NULL" isEqualToString:value]
        || [value isEqualToString:@"<null>"]
        || [value isEqualToString:@"(null)"]
        || [value isEqualToString:@"null"]) {
        return YES;
    }
    // 删除两端的空格和回车
    NSString *str = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return (str.length <= 0);
}


#pragma mark -
#pragma mark 删除字符串两端的空格与回车
+ (NSString *)stringByTrimmingWhitespaceAndNewline:(NSString *)value
{
    if ([NEXSysUtil validateObjectIsNull:value]) {
        return @"";
    }
    
    return [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}


#pragma mark -
#pragma mark 金额保留N位小数，且不四舍五入
+ (NSString *)stringNotRoundNumberString:(NSString *)numberString afterPoint:(NSInteger)position
{
    NSDecimalNumberHandler* roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundDown
                                                                                                      scale:position
                                                                                           raiseOnExactness:NO
                                                                                            raiseOnOverflow:NO
                                                                                           raiseOnUnderflow:NO
                                                                                        raiseOnDivideByZero:NO];
    NSDecimalNumber *ouncesDecimal = [[NSDecimalNumber alloc] initWithString:numberString];
    NSDecimalNumber *roundedOunces = [ouncesDecimal decimalNumberByRoundingAccordingToBehavior:roundingBehavior];
    return [NSString stringWithFormat:@"%@", roundedOunces];
}

#pragma mark 格式化金钱数据，且不四舍五入
+ (NSString *)stringToDealMoneyString:(NSString *)moneyString formatter:(NSString *)format maximumFractionDigits:(NSInteger)maximumDigits
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [formatter setRoundingMode:NSNumberFormatterRoundFloor];
    [formatter setMaximumFractionDigits:maximumDigits];
    [formatter setPositiveFormat:@"###,##0.00;"];
    if (format && format.length > 0) {
        [formatter setPositiveFormat:format];
    }
    NSNumber *money_number = [formatter numberFromString:moneyString];
    NSString *money_formatter_string = [formatter stringFromNumber:money_number];
    return money_formatter_string;
}


#pragma mark -
#pragma mark 获取所有字体名称列表
+ (NSArray<NSString *> *)getAllFontFamilyNames
{
    NSMutableArray<NSString *> *fontNames = [NSMutableArray array];
    for(NSString *fontfamilyname in [UIFont familyNames]) {
        NEXLog(@"Family:'%@'",fontfamilyname);
        for(NSString *fontName in [UIFont fontNamesForFamilyName:fontfamilyname]) {
            [fontNames addObject:fontName];
            NEXLog(@"\tFont:'%@'",fontName);
        }
    }
    return [NSArray arrayWithArray:fontNames];
}


@end


