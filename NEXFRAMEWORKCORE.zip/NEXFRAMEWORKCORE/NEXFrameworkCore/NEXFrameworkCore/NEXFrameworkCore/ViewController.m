//
//  ViewController.m
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


#pragma mark -
#pragma mark 生命周期
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"核心模块";
}


@end
