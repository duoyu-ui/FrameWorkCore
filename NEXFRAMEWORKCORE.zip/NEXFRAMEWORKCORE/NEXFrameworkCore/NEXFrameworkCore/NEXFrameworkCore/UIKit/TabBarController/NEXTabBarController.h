//
//  NEXTabBarController.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/26.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NEXTabBarController : UITabBarController

#pragma mark 添加子导航控制器
- (void)addChildNavigationController:(Class)navigationControllerClass
                  rootViewController:(Class)rootViewControllerClass
                     navigationTitle:(NSString *)navigationTitle
                     tabBarItemTitle:(NSString *)tabBarItemTitle
               tabBarNormalImageName:(NSString *)normalImageName
               tabBarSelectImageName:(NSString *)selectImageName
                   tabBarItemEnabled:(BOOL)enabled;

@end
