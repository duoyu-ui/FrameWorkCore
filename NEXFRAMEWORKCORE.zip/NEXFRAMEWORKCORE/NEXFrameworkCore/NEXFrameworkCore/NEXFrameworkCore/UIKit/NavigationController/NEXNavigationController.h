//
//  NEXNavigationController.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/26.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NEXNavigationController : UINavigationController

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated;

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated title:(NSString *)title;

- (void)setViewControllers:(NSArray<__kindof UIViewController *> *)viewControllers;

- (void)setViewControllers:(NSArray<UIViewController *> *)viewControllers animated:(BOOL)animated;

@end
