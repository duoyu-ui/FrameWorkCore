//
//  NEXTabBarController+InterfaceOrientation.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/7/14.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabBarController.h"

@interface NEXTabBarController (InterfaceOrientation)

@end
