//
//  NEXNetworkViewController.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/30.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXNavBarViewController.h"
@class NEXNetworkViewController;

#if __has_include(<NEXNetwork/NEXNetwork.h>)
#import <NEXNetwork/NEXNetworkReachabilityUtil.h>
#else
#import "NEXNetworkReachabilityUtil.h"
#endif

@protocol NEXNetworkViewControllerProtocol <NSObject>
@optional
- (void)currentNetworkReachabilityStatus:(NEXNetworkStatus)currentNetworkStatus inViewController:(NEXNetworkViewController *)inViewController;
@end

@interface NEXNetworkViewController : NEXNavBarViewController <NEXNetworkViewControllerProtocol>

#pragma mark 监听网络变化后执行 - 有网络
- (void)viewDidLoadWithNetworkingStatus;

#pragma mark 监听网络变化后执行 - 无网络
- (void)viewDidLoadWithNoNetworkingStatus;

@end

