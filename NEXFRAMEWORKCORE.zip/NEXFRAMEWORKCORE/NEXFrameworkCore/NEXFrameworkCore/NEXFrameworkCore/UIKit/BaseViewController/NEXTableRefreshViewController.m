//
//  NEXTableRefreshViewController.m
//  ZHONGLELOTTERY
//
//  Created by MASON on 2018/2/27.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTableRefreshViewController.h"
#import "NEXTableRefreshViewController+EmptyDataSet.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "NEXAutosizingUtil.h"
#import "UIColor+Extension.h"
#import "NEXSysCoreMacro.h"
#import "NEXSysConst.h"
#import "NEXSysUtil.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

#if __has_include(<NEXNetwork/NEXNetwork.h>)
#import <NEXNetwork/NEXNetwork.h>
#else
#import "NEXNetwork.h"
#endif

#if __has_include(<NEXRefresh/NEXRefresh.h>)
#import <NEXRefresh/NEXRefresh.h>
#else
#import "NEXRefresh.h"
#endif

#if __has_include(<Masonry/Masonry.h>)
#import <Masonry/Masonry.h>
#else
#import "Masonry.h"
#endif

#if __has_include(<DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>)
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#else
#import "UIScrollView+EmptyDataSet.h"
#endif

#if __has_include(<UITableView+FDTemplateLayoutCell/UITableView+FDTemplateLayoutCell.h>)
#import <UITableView+FDTemplateLayoutCell/UITableView+FDTemplateLayoutCell.h>
#else
#import "UITableView+FDTemplateLayoutCell.h"
#endif


@interface NEXTableRefreshViewController () <UITableViewDelegate, UITableViewDataSource>

@end

@implementation NEXTableRefreshViewController


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        _page = 0;
        _limit = 10;
        _offset = 0;
        
        _hasTableViewRefresh = YES; // 是否创建表格（默认YES）
        _hasRefreshHeader = YES; // 是否可下拉刷新（默认YES）
        _hasRefreshFooter = YES; // 是否可上拉加载（默认YES）
        _hasRefreshOnce = NO; // 是否只可下拉刷新1次（默认NO）(数据固定的页面使用，如：我的、设置)
        _hasCacheData = NO; // 是否需要加载缓存（默认NO）
        _hasPage = NO; // 是否需要分页（默认NO）
        _isAESParam = YES; // 默认加密参数
        
        _requestMethod = NEXRequestMethodGET; // 默认GET请求
        
        _isEmptyDataSetShouldDisplay = NO; // 是否显示EmptyDataSet空白页（默认NO）
        _isEmptyDataSetShouldAllowScroll = YES; // 是否允许滚动（默认YES）
        _isEmptyDataSetShouldAllowImageViewAnimate = YES; // 图片是否要动画效果（默认YES）
        
        self.isAutoLayoutSafeAreaTop = YES; // 是否自动适配安全区域（iOS11安全区域）
        self.isAutoLayoutSafeAreaBottom = NO; // 是否自动适配安全区域（iOS11安全区域）
    }
    return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
}


#pragma mark 监听网络变化后执行 - 有网络
- (void)viewDidLoadWithNetworkingStatus
{
    // 配置UI界面
    [self createUIRefreshTable:YES];
    
    // 请求网络数据
    [self.tableViewRefresh.mj_header beginRefreshing];
}


#pragma mark 监听网络变化后执行 - 无网络
- (void)viewDidLoadWithNoNetworkingStatus
{
    // 配置UI界面
    [self createUIRefreshTable:YES];
    
    // 重新设置可刷新数据
    [self.tableViewRefresh setMj_header:self.tableViewRefreshHeader];
    [self.tableViewRefresh setMj_footer:self.tableViewRefreshFooter];
    
    // 请求网络数据
    [self.tableViewRefresh.mj_header beginRefreshing];
}


#pragma mark -
#pragma mark -
#pragma mark 请求地址（子类继承实现）
- (NSString *)getRequestURLString
{
    return [NEXNetworkHTTPSessionUtil makeRequestWithBaseURLString:nil URLString:nil];
}

#pragma mark 请求参数（子类继承实现）
- (NSMutableDictionary *)getRequestParamerter
{
    return [NEXNetworkHTTPSessionUtil makeRequestParamerterWithKeys:nil Values:nil];
}

#pragma mark 刷新加载数据（下拉刷新数据）
- (void)loadData
{
    // 每次刷新时重置
    self.offset = 0;
    self.page = self.offset/self.limit + 1;
    
    // 加载更多数据
    [self loadMoreData];
    
}


#pragma mark 加载更多数据（上拉加载数据）
- (void)loadMoreData
{
    WEAKSELF(weakSelf);
    
    NEXLog(@"加载前：第[%ld]页，偏移量[%ld]，限制量[%ld]", weakSelf.page, weakSelf.offset, self.limit);
    
    // 加载完数据前，其它操作
    [self viewDidLoadBeforeLoadNetworkDataOrCacheData];
    
    // 验证网络状态，无网则直接返回
    if (![NEXNetworkReachabilityUtil isNetworkAvailable]) {
        
        // 请求数据
        [self loadNetworkDataThen:^(BOOL success, NSUInteger count){
            
            // 没有数据显示空白页面
            if (count > 0 || (count == 0 && weakSelf.offset > 0)) {
                [weakSelf.tableViewRefresh setMj_footer:weakSelf.tableViewRefreshFooter];
            } else {
                [weakSelf.tableViewRefresh setMj_footer:nil];
            }
            
            if (count < weakSelf.limit) {
                
                // 下拉刷新控件，没有更多数据
                [weakSelf.tableViewRefresh.mj_header endRefreshing];
                
                // 上拉刷新控件，没有更多数据
                [weakSelf.tableViewRefresh.mj_footer endRefreshingWithNoMoreData];
                
                // 上拉刷新控件，置空（不显示已加载完成数据）
                // weakSelf.tableViewRefresh.mj_footer = nil;
                
            } else {
                
                // 下拉刷新控件，结束刷新状态
                [weakSelf.tableViewRefresh.mj_header endRefreshing];
                
                // 上拉刷新控件，结束刷新状态
                [weakSelf.tableViewRefresh.mj_footer endRefreshing];
                
                // 上拉刷新控件，重新赋值
                [weakSelf.tableViewRefreshFooter setState:MJRefreshStateIdle];
                [weakSelf.tableViewRefresh setMj_footer:weakSelf.tableViewRefreshFooter];
                
            }
            
            // 加载成功
            if (success && count) {
                
                // 刷新表格
                [weakSelf.tableViewRefresh reloadData];
                
                // 增加偏移量
                if (count < weakSelf.limit) {
                    weakSelf.offset += count;
                } else {
                    weakSelf.offset += weakSelf.limit;
                }
                weakSelf.page = weakSelf.offset/weakSelf.limit + 1;
                
                // 是否只可下拉刷新1次（默认NO）
                if (weakSelf.hasRefreshOnce) {
                    [weakSelf.tableViewRefresh setMj_header:nil];
                    [weakSelf.tableViewRefresh setMj_footer:nil];
                }
                
            }  else {
                
                // 刷新表格
                [weakSelf.tableViewRefresh reloadData];
                
                // 是否显示EmptyDataSet空白页（默认NO）
                [weakSelf setIsEmptyDataSetShouldDisplay:YES];
                
                // 刷新加载EmptyDataSet空白页
                [weakSelf.tableViewRefresh reloadEmptyDataSet];
                
            }
            
            NEXLog(@"加载后：第[%ld]页，偏移量[%ld]，限制量[%ld]", weakSelf.page, weakSelf.offset, self.limit);
            
            // 加载完数据后，其它操作
            [weakSelf viewDidLoadAfterLoadNetworkDataOrCacheData];
            
        }];
        
    } else {
        
        // 请求数据
        [self loadNetworkDataThen:^(BOOL success, NSUInteger count){
            
            // 没有数据显示空白页面
            if (count > 0 || (count == 0 && weakSelf.offset > 0)) {
                [weakSelf.tableViewRefresh setMj_footer:weakSelf.tableViewRefreshFooter];
            } else {
                [weakSelf.tableViewRefresh setMj_footer:nil];
            }
            
            if (count < weakSelf.limit) {
                
                // 下拉刷新控件，没有更多数据
                [weakSelf.tableViewRefresh.mj_header endRefreshing];
                
                // 上拉刷新控件，没有更多数据
                [weakSelf.tableViewRefresh.mj_footer endRefreshingWithNoMoreData];
                
                // 上拉刷新控件，置空（不显示已加载完成数据）
                // weakSelf.tableViewRefresh.mj_footer = nil;
                
            } else {
                
                // 下拉刷新控件，结束刷新状态
                [weakSelf.tableViewRefresh.mj_header endRefreshing];
                
                // 上拉刷新控件，结束刷新状态
                [weakSelf.tableViewRefresh.mj_footer endRefreshing];
                
                // 上拉刷新控件，重新赋值
                [weakSelf.tableViewRefreshFooter setState:MJRefreshStateIdle];
                [weakSelf.tableViewRefresh setMj_footer:weakSelf.tableViewRefreshFooter];
                
            }
            
            // 加载成功
            if (success && count > 0) {
                
                // 刷新表格
                [weakSelf.tableViewRefresh reloadData];
                
                // 增加偏移量
                if (count < weakSelf.limit) {
                    weakSelf.offset += count;
                } else {
                    weakSelf.offset += weakSelf.limit;
                }
                weakSelf.page = weakSelf.offset/weakSelf.limit + 1;
                
                // 是否只可下拉刷新1次（默认NO）
                if (weakSelf.hasRefreshOnce) {
                    [weakSelf.tableViewRefresh setMj_header:nil];
                    [weakSelf.tableViewRefresh setMj_footer:nil];
                }
                
            } else {
                
                // 刷新表格
                [weakSelf.tableViewRefresh reloadData];
                
                // 是否显示EmptyDataSet空白页（默认NO）
                [weakSelf setIsEmptyDataSetShouldDisplay:YES];
                
                // 刷新加载EmptyDataSet空白页
                [weakSelf.tableViewRefresh reloadEmptyDataSet];
    
            }
            
            NEXLog(@"加载后：第[%ld]页，偏移量[%ld]，限制量[%ld]", weakSelf.page, weakSelf.offset, self.limit);
            
            // 加载完数据后，其它操作
            [weakSelf viewDidLoadAfterLoadNetworkDataOrCacheData];
            
        }];
        
    }
    
}


#pragma mark 请求网络数据
- (void)loadNetworkDataThen:(void (^)(BOOL success, NSUInteger count))then
{
    WEAKSELF(weakSelf);
    
    // 请求数据是否成功
    __block BOOL isSuccess = NO;
    __block NSUInteger listCount = 0; // 请求到的数据数量
    
    // 请求地址与参数
    NSString *url = [weakSelf getRequestURLString];
    NSMutableDictionary *params = [weakSelf getRequestParamerter];
    
    // 验证请求连接的正确性
    if ([NEXSysUtil validateStringEmpty:url]) {
        // 刷新界面
        !then ?: then(isSuccess, listCount);
        return ;
    }
    
    // 数据分页处理
    if (self.hasPage) {
        [params setObject:[NSNumber numberWithInteger:_offset] forKey:@"index"];
        [params setObject:[NSNumber numberWithInteger:_limit] forKey:@"count"];
    }
    NEXLog(@"\n请求地址：%@ \n请求参数：%@", url, params);
    
    // 请求网络数据
    switch (self.requestMethod) {
            // 网络GET请求
        case NEXRequestMethodGET: {
            return [NEXNetworkHTTPSessionUtil GET:url parameters:params responseCache:^(id responseCache) {
                
                // 是否需要加载缓存（默认NO）
                if (self->_hasCacheData) {
                    
                    // 加载解析缓存数据
                    NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheData:responseCache isCacheData:YES];
                    
                    // 更新请求数据状态（用于刷新数据表格）
                    listCount = responseTableData.count;
                    if (listCount > 0) {
                        isSuccess = YES;
                        NEXLog(@"加载解析缓存数据成功");
                    } else {
                        isSuccess = YES;
                        NEXLog(@"没有更多数据");
                    }
                    
                    // 刷新界面
                    !then ?: then(isSuccess, listCount);
                    
                }
                
            } success:^(id responseObject) {
                
                // 加载解析网络数据
                NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheData:responseObject isCacheData:NO];
                
                // 更新请求数据状态（用于刷新数据表格）
                listCount = responseTableData.count - (weakSelf.page-1)*weakSelf.limit;
                if (listCount > 0) {
                    isSuccess = YES;
                    NEXLog(@"加载请求网络数据成功");
                } else {
                    isSuccess = YES;
                    NEXLog(@"没有更多数据");
                }
                
                // 刷新界面
                !then ?: then(isSuccess, listCount);
                
            } failure:^(NSError *error) {
                
                NEXLog(@"加载请求网络数据异常：%@", error);
                
                // 刷新界面
                !then ?: then(isSuccess, listCount);
                
            } showMessage:nil showProgressHUD:NO isHideErrorMessage:NO];
        }
            // 网络POST请求
        case NEXRequestMethodPOST: {
            return [NEXNetworkHTTPSessionUtil POST:url parameters:params responseCache:^(id responseCache) {
                
                // 是否需要加载缓存（默认NO）
                if (self->_hasCacheData) {
                    
                    // 加载解析缓存数据
                    NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheData:responseCache isCacheData:YES];
                    
                    // 更新请求数据状态（用于刷新数据表格）
                    listCount = responseTableData.count;
                    if (listCount > 0) {
                        isSuccess = YES;
                        NEXLog(@"加载解析缓存数据成功");
                    } else {
                        isSuccess = YES;
                        NEXLog(@"没有更多数据");
                    }
                    
                    // 刷新界面
                    !then ?: then(isSuccess, listCount);
                    
                }
                
            } success:^(id responseObject) {
                
                // 加载解析网络数据
                NSMutableArray *responseTableData = [weakSelf loadNetworkDataOrCacheData:responseObject isCacheData:NO];
                
                // 更新请求数据状态（用于刷新数据表格）
                listCount = responseTableData.count - (weakSelf.page-1)*weakSelf.limit;
                if (listCount > 0) {
                    isSuccess = YES;
                    NEXLog(@"加载请求网络数据成功");
                } else {
                    isSuccess = YES;
                    NEXLog(@"没有更多数据");
                }
                
                // 刷新界面
                !then ?: then(isSuccess, listCount);
                
            } failure:^(NSError *error) {
                
                NEXLog(@"加载请求网络数据异常：%@", error);
                
                // 刷新界面
                !then ?: then(isSuccess, listCount);
                
            } showMessage:nil showProgressHUD:NO isHideErrorMessage:NO];
        }
        default: {
            return;
        }
    }
    
    
}


#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    // TODO: 子类继承实现处理过程
    
    return nil;
}

#pragma mark 加载完数据前，其它操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeLoadNetworkDataOrCacheData
{
    // TODO: 子类继承，加载完数据前，进行相关操作，每次刷新加载数据前都会执行
    
}

#pragma mark 加载完数据后，其它操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadNetworkDataOrCacheData
{
    // TODO: 子类继承，加载完数据后，进行相关操作，每次刷新加载数据前都会执行
    
}


#pragma mark -
#pragma mark 创建界面表格
- (void)createUIRefreshTable:(BOOL)force
{
    // 是否创建表格
    if (!_hasTableViewRefresh) {
        return;
    }
    
    // 表格已经存在则无需创建，直接返回；否则强制创建表格
    if (self.tableViewRefresh && !force) {
        return;
    }
    
    // 强制创建表格
    if (force && self.tableViewRefresh) {
        [self.tableViewRefresh removeFromSuperview];
        [self setTableViewRefresh:nil];
    }
    
    // 表格已经存在则无需创建，直接返回；否则强制创建表格
    if (self.tableViewRefresh && !force) {
        return;
    }
    
    // 创建表格
    {
        // 设置表格
        self.tableViewRefresh = [[UITableView alloc] initWithFrame:CGRectZero style:[self tableViewRefreshStyle]];
        self.tableViewRefresh.delegate = self;
        self.tableViewRefresh.dataSource = self;
        self.tableViewRefresh.estimatedRowHeight = 200;
        // 设置后在 iPhone5 上报错
        // self.tableViewRefresh.estimatedSectionHeaderHeight = NEX_FLOAT_MIN;
        // self.tableViewRefresh.estimatedSectionFooterHeight = NEX_FLOAT_MIN;
        self.tableViewRefresh.sectionHeaderHeight = NEX_FLOAT_MIN;
        self.tableViewRefresh.sectionFooterHeight = NEX_FLOAT_MIN;
        self.tableViewRefresh.fd_debugLogEnabled = YES;
        self.tableViewRefresh.showsVerticalScrollIndicator = NO;
        self.tableViewRefresh.backgroundColor = [UIColor whiteColor];
        self.tableViewRefresh.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self.view addSubview:self.tableViewRefresh];
        
        // 空白页展示
        self.tableViewRefresh.emptyDataSetSource = self;
        self.tableViewRefresh.emptyDataSetDelegate = self;
        
        // 计算表格位置
        switch ([self preferredNavigationBarType]) {
                // 系统导航栏
            case NEXNavBarTypeDefault: {
                if ([self prefersNavigationBarHidden]) {
                    // 系统导航栏已隐藏-自定义导航栏UINavigationBar
                    if ([self prefersStatusBarHidden]) {
                        [self.tableViewRefresh setFrame:CGRectMake(0, STATUS_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT)];
                    } else {
                        [self.tableViewRefresh setFrame:CGRectMake(0, STATUS_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-STATUS_BAR_HEIGHT)];
                    }
                    if (IS_IPHONE_X) {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            if (@available(iOS 11.0, *)) {
                                if (self.isAutoLayoutSafeAreaTop) {
                                    make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
                                } else {
                                    make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                }
                                if (self.isAutoLayoutSafeAreaBottom) {
                                    make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
                                } else {
                                    make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                                }
                            } else {
                                make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                            }
                        }];
                    } else {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            make.top.equalTo(self.mas_topLayoutGuide).with.offset(0.0);
                            make.bottom.equalTo(self.mas_bottomLayoutGuide).with.offset(0.0);
                        }];
                    }
                } else {
                    // 系统导航栏未隐藏-自定义导航栏TitleView
                    [self.tableViewRefresh setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT)];
                    if (IS_IPHONE_X) {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            if (@available(iOS 11.0, *)) {
                                if (self.isAutoLayoutSafeAreaTop) {
                                    make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
                                } else {
                                    make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                }
                                if (self.isAutoLayoutSafeAreaBottom) {
                                    make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
                                } else {
                                    make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                                }
                            } else {
                                make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                            }
                        }];
                    } else {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            make.top.equalTo(self.mas_topLayoutGuide).with.offset(0.0);
                            make.bottom.equalTo(self.mas_bottomLayoutGuide).with.offset(0.0);
                        }];
                    }
                }
                break;
            }
                // 自定义导航栏
            case NEXNavBarTypeCustom: {
                if ([self prefersNavigationBarHidden]) {
                    // 系统导航栏已隐藏-自定义导航栏UINavigationBar
                    if ([self prefersStatusBarHidden]) {
                        [self.tableViewRefresh setFrame:CGRectMake(0, STATUS_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT)];
                    } else {
                        [self.tableViewRefresh setFrame:CGRectMake(0, STATUS_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-STATUS_BAR_HEIGHT)];
                    }
                    if (IS_IPHONE_X) {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            if (@available(iOS 11.0, *)) {
                                if (self.isAutoLayoutSafeAreaTop) {
                                    make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
                                } else {
                                    make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                }
                                if (self.isAutoLayoutSafeAreaBottom) {
                                    make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
                                } else {
                                    make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                                }
                            } else {
                                make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                            }
                        }];
                    } else {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            make.top.equalTo(self.mas_topLayoutGuide).with.offset(0.0);
                            make.bottom.equalTo(self.mas_bottomLayoutGuide).with.offset(0.0);
                        }];
                    }
                } else {
                    // 系统导航栏未隐藏-自定义导航栏TitleView
                    [self.tableViewRefresh setFrame:CGRectMake(0, STATUS_NAVIGATION_BAR_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT-STATUS_NAVIGATION_BAR_HEIGHT)];
                    if (IS_IPHONE_X) {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            if (@available(iOS 11.0, *)) {
                                if (self.isAutoLayoutSafeAreaTop) {
                                    make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
                                } else {
                                    make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                }
                                if (self.isAutoLayoutSafeAreaBottom) {
                                    make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
                                } else {
                                    make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                                }
                            } else {
                                make.top.equalTo(self.view.mas_top).with.offset(0.0);
                                make.bottom.equalTo(self.view.mas_bottom).with.offset(0.0);
                            }
                        }];
                    } else {
                        [self.tableViewRefresh mas_remakeConstraints:^(MASConstraintMaker *make) {
                            make.left.equalTo(self.view.mas_left);
                            make.right.equalTo(self.view.mas_right);
                            make.top.equalTo(self.mas_topLayoutGuide).with.offset(0.0);
                            make.bottom.equalTo(self.mas_bottomLayoutGuide).with.offset(0.0);
                        }];
                    }
                }
                break;
            }
            default: {
                break;
            }
        }
        
        // 设置背景
        UIView *backgroundView = [[UIView alloc] init];
        [backgroundView setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [self.tableViewRefresh setBackgroundView:backgroundView];
        
        // 表头表尾
        [self.tableViewRefresh setTableHeaderView:[[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, NEX_FLOAT_MIN)]];
        [self.tableViewRefresh setTableFooterView:[[UIView alloc] initWithFrame:CGRectMake(0, 0, 0, NEX_FLOAT_MIN)]];
        
        // 下拉刷新
        if (self.hasRefreshHeader) {
            MJRefreshHeader *refreshHeader = [NEXRefreshCircleHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
            [refreshHeader setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
            [self setTableViewRefreshHeader:refreshHeader];
            [self.tableViewRefresh setMj_header:refreshHeader];
        }
        
        // 上拉加载
        if (self.hasRefreshFooter) {
            MJRefreshAutoNormalFooter *refreshFooter = [NEXRefreshCircleFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
            [refreshFooter setTitle:NEXRefreshAutoFooterIdleText forState:MJRefreshStateIdle];
            [refreshFooter setTitle:NEXRefreshAutoFooterRefreshingText forState:MJRefreshStateRefreshing];
            [refreshFooter setTitle:NEXRefreshAutoFooterNoMoreDataText forState:MJRefreshStateNoMoreData];
            [refreshFooter.stateLabel setFont:[UIFont systemFontOfSize:NEX_AUTOSIZING_FONT(NEXRefreshAutoFooterFontSize)]];
            [refreshFooter.stateLabel setTextColor:[UIColor colorWithRed:0.50 green:0.50 blue:0.51 alpha:1.00]];
            [refreshFooter setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
            [self setTableViewRefreshFooter:refreshFooter];
        }
        
        // 必须被注册到 UITableView 中
        [self tableViewRefreshRegisterClass:self.tableViewRefresh];
        
    }
    
}


#pragma mark 注册UITableViewCell（子类继承实现）
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
    
}


#pragma mark 表格类型
- (UITableViewStyle)tableViewRefreshStyle
{
    return UITableViewStyleGrouped;
}


#pragma mark 数据模型（懒加载）
- (NSMutableArray *)tableDataRefresh
{
    if (!_tableDataRefresh) {
        _tableDataRefresh = [NSMutableArray array];
    }
    return _tableDataRefresh;
}

#pragma mark - TableView data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 0.0f;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0.0f;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 0.0f;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    CGFloat height = 0.01f;
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, height)];
    [headerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];

    return headerView;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    CGFloat height = 0.01f;
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableViewRefresh.frame.size.width, height)];
    [footerView setBackgroundColor:COLOR_TABLEVIEW_HEADER_VIEW_BACKGROUND_DEFAULT];
    
    return footerView;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01f;
}


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01f;
}

@end

