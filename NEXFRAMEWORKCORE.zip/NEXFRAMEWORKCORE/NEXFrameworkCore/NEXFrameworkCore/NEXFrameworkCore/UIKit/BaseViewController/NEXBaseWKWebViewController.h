//
//  NEXBaseWKWebViewController.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <WebKit/WebKit.h>
#import "NEXBaseCommonViewController.h"
#import "WebViewJavascriptBridge.h"


@interface NEXBaseWKWebViewController : NEXBaseCommonViewController

@property (nonatomic, copy) NSString *htmlUrlString;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) WKWebViewConfiguration *config;
@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) WebViewJavascriptBridge* bridge;

@property (assign, nonatomic) BOOL hasShowCloseButton;
@property (strong, nonatomic) UIButton *closeButton;

#pragma mark 事件处理 - 刷新
- (void)pressButtonWebViewRefreshAction;
#pragma mark 事件处理 - 后退
- (void)pressButtonWebViewGoBackAction;
#pragma mark 事件处理 - 前进
- (void)pressButtonWebViewGoForwardAction;
#pragma mark 事件处理 - 关闭
- (void)pressButtonWebViewCloseAction;

#pragma mark 初始化 - 网络
- (instancetype)initWithHTMLUrlString:(NSString *)htmlUrlString;

#pragma mark 初始化 - 本地
- (instancetype)initWithLocalHTMLString:(NSString *)htmlUrlString;

#pragma mark JS与OC处理交互
- (void)webViewJavascriptBridgeRegisterHandler;

@end
