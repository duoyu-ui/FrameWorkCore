//
//  NEXBaseCommonViewController.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXBaseCoreViewController.h"

@interface NEXBaseCommonViewController : NEXBaseCoreViewController

/**
 * 是否自动适配安全区域（iOS11安全区域）
 */
@property (nonatomic, assign) BOOL isAutoLayoutSafeAreaTop;
/**
 * 是否自动适配安全区域（iOS11安全区域）
 */
@property (nonatomic, assign) BOOL isAutoLayoutSafeAreaBottom;

@end
