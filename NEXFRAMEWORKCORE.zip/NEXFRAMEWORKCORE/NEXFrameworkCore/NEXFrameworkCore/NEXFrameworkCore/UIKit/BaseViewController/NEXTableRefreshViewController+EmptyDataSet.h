//
//  NEXTableRefreshViewController+EmptyDataSet.h
//  ZHONGLELOTTERY
//
//  Created by MASON on 2018/2/27.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTableRefreshViewController.h"

#if __has_include(<DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>)
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#else
#import "UIScrollView+EmptyDataSet.h"
#endif

@interface NEXTableRefreshViewController (EmptyDataSet) <DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

@end
