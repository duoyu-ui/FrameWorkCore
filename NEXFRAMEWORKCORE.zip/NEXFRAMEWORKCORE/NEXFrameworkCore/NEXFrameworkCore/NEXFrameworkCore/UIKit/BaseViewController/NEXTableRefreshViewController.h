//
//  NEXTableRefreshViewController.h
//  ZHONGLELOTTERY
//
//  Created by MASON on 2018/2/27.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXBaseCommonViewController.h"

#if __has_include(<MJRefresh/MJRefresh.h>)
#import <MJRefresh/MJRefresh.h>
#else
#import "MJRefresh.h"
#endif

#if __has_include(<NEXNetwork/NEXNetwork.h>)
#import <NEXNetwork/NEXBaseRequest.h>
#else
#import "NEXBaseRequest.h"
#endif

@interface NEXTableRefreshViewController : NEXBaseCommonViewController

@property (nonatomic, strong) UITableView *tableViewRefresh; // UITableView表格

@property (nonatomic, assign) UITableViewStyle tableViewRefreshStyle; // UITableView表格类型

@property (nonatomic, strong) NSMutableArray *tableDataRefresh; // UITableView数据源

@property (nonatomic, strong) MJRefreshHeader *tableViewRefreshHeader; // 下拉刷新控件

@property (nonatomic, strong) MJRefreshFooter *tableViewRefreshFooter; // 上拉刷新控件

@property (nonatomic, assign) BOOL hasTableViewRefresh; // 是否创建UITableView表格（默认创建）

@property (nonatomic, assign) BOOL hasRefreshHeader; // 是否可下拉刷新（默认YES）

@property (nonatomic, assign) BOOL hasRefreshFooter; // 是否可上拉刷新（默认YES）

@property (nonatomic, assign) BOOL hasRefreshOnce; // 是否只可下拉刷新1次（默认NO）(数据固定的页面使用，如：我的、设置)

@property (nonatomic, assign) BOOL hasCacheData; // 是否需要加载缓存（默认NO）

@property (nonatomic, assign) BOOL hasPage; // 是否需要分页（默认NO）

@property (nonatomic, assign) BOOL isAESParam; // 参数是否加密（默认YES）

@property (nonatomic, assign) NSUInteger page; // 页数

@property (nonatomic, assign) NSUInteger limit; // 数量限制

@property (nonatomic, assign) NSUInteger offset; // 数据偏移量

@property (nonatomic, assign) NEXRequestMethod requestMethod; // 请求方式

@property (nonatomic, assign) BOOL isEmptyDataSetShouldDisplay; // 是否显示EmptyDataSet空白页（默认NO）

@property (nonatomic, assign) BOOL isEmptyDataSetShouldAllowScroll; // 是否允许滚动（默认YES）

@property (nonatomic, assign) BOOL isEmptyDataSetShouldAllowImageViewAnimate; // 图片是否要动画效果（默认YES）


#pragma mark 请求地址（子类继承实现）
- (NSString *)getRequestURLString;

#pragma mark 请求参数（子类继承实现）
- (NSMutableDictionary *)getRequestParamerter;

#pragma mark 请求网络数据（下拉刷新数据）
- (void)loadData;

#pragma mark 请求网络数据（上拉加载数据）
- (void)loadMoreData;

#pragma mark 请求网络数据（请求逻辑处理）
- (void)loadNetworkDataThen:(void (^)(BOOL success, NSUInteger count))then;

#pragma mark 请求网络数据或加载缓存（子类继承实现处理过程）
- (NSMutableArray *)loadNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData;

#pragma mark 加载完数据前，其它操作，每次刷新加载数据前都会执行
- (void)viewDidLoadBeforeLoadNetworkDataOrCacheData;

#pragma mark 加载完数据后，其它操作，每次刷新加载数据后都会执行
- (void)viewDidLoadAfterLoadNetworkDataOrCacheData;

#pragma mark 创建界面表格
- (void)createUIRefreshTable:(BOOL)force;

#pragma mark 注册UITableViewCell（子类继承实现）
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView;

#pragma mark TableView Data Source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section;
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section;
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section;


@end


