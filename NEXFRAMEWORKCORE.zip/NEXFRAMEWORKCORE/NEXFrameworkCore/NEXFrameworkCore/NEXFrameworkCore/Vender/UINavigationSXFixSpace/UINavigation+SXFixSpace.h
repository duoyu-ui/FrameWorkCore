

#import <UIKit/UIKit.h>

#ifndef sx_defaultFixSpace
#define sx_defaultFixSpace 0
#endif

@interface UIImagePickerController (SXFixSpace)
@end

@interface UINavigationBar (SXFixSpace)
@end

@interface UINavigationItem (SXFixSpace)
@end

