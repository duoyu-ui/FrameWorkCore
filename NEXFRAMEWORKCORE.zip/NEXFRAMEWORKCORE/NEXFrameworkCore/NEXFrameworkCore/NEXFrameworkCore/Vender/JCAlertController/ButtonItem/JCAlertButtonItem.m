//
//  JCAlertButtonItem.m
//  JCAlertController
//
//  Created by HJaycee on 2017/4/5.
//  Copyright © 2017年 HJaycee. All rights reserved.
//

#import "JCAlertButtonItem.h"

@implementation JCAlertButtonItem

@end
