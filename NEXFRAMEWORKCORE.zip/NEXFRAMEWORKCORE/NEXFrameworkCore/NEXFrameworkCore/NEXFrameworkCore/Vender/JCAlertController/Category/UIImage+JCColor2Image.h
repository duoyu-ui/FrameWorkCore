//
//  UIImage+JCColor2Image.h
//  JCAlertController
//
//  Created by HJaycee on 2017/4/5.
//  Copyright © 2017年 HJaycee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (JCColor2Image)

+(UIImage *)createImageWithColor:(UIColor *)color;

@end
