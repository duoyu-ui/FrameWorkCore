//
//  NEXFrameworkCoreAppDelegate.m
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXFrameworkCoreAppDelegate.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

@implementation NEXFrameworkCoreAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NEXLog(@"核心模块 -> 加载核心模块");

    return YES;
}

@end

