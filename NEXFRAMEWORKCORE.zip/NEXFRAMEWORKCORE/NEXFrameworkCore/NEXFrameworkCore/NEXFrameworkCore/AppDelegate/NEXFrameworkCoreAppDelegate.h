//
//  NEXFrameworkCoreAppDelegate.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#if __has_include(<NEXModuleManager/NEXModuleAppManager.h>)
#import <NEXModuleManager/NEXModuleAppManager.h>
#else
#import "NEXModuleAppManager.h"
#endif

@interface NEXFrameworkCoreAppDelegate : NSObject  <NEXModuleApplicationDelegate>


@end
