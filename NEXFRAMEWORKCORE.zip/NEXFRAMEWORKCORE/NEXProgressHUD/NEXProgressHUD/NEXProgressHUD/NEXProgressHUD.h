//
//  NEXAlertUtil.h
//  NEXAlertUtil
//
//  Created by MASON on 2017/11/6.
//  Copyright © 2017年 MASON. All rights reserved.
//

#ifndef _NEX_PROGRESS_HUD_UTIL_
#define _NEX_PROGRESS_HUD_UTIL_

#if __has_include(<NEXProgressHUD/NEXProgressHUD.h>)

FOUNDATION_EXPORT double NEXProgressHUDVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXProgressHUDVersionString[];

#import <NEXProgressHUD/NEXProgressHUDUtil.h>
#import <NEXProgressHUD/NEXProgressAlertUtil.h>

#else

#import "NEXProgressHUDUtil.h"
#import "NEXProgressAlertUtil.h"

#endif /* __has_include */

#endif /* _NEX_PROGRESS_HUD_UTIL_ */
