//
//  ViewController.m
//  NEXProgressHUD
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "ViewController.h"
#import "NEXProgressAlertUtil.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    label.center = self.view.center;
    label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:label];
    label.text = @"点击任意位置测试";
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    //[NEXProgressAlertUtil showMessage:@"弹出提示框" toView:self.view];
    //[NEXProgressAlertUtil showFailWithMessage:@"弹出提示框" toView:self.view];
    //[NEXProgressAlertUtil showSuccessWithMessage:@"弹出提示框" toView:self.view];
    //[NEXProgressAlertUtil showWarningWithMessage:@"弹出提示框" toView:self.view];
    //[NEXProgressAlertUtil showGrayLoadingToView:self.view];
    //[NEXProgressAlertUtil showGaryLoadingWithMessage:@"弹出提示框" toView:self.view];
    [NEXProgressAlertUtil showWhiteLoadingToView:self.view];
    //[NEXProgressAlertUtil showWhiteLoadingWithMessage:@"弹出提示框" toView:self.view];
    //[NEXProgressAlertUtil showMessageToWindow:@"提示信息"];
    
    __block NSInteger time = 2; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), 1.0*NSEC_PER_SEC, 0); // 每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(time <= 0){ // 倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [NEXProgressAlertUtil hideHUDForView:self.view];
                
            });
        } else {
            time--;
        }
    });
    dispatch_resume(_timer);
}

@end


