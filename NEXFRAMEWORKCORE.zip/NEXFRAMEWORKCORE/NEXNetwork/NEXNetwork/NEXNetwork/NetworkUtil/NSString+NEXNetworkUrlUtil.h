//
//  NSString+NEXNetworkUrlUtil.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NEXNetworkUrlUtil)

- (NSString *)networkUrlStringByAppendURLParameters:(NSDictionary *)parameters;

@end

