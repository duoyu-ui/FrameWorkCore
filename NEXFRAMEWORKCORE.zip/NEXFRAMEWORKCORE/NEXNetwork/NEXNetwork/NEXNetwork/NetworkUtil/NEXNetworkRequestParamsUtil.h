//
//  NEXNetworkRequestParamsUtil.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/17.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NEX_PARAMS_NULL               @""
#define NEX_PARAMS_ZERO               @"0"
#define NEX_MOBILE_TYPE_IOS           @"1" //IOS
#define NEX_MOBILE_TYPE_IOS_LOGIN     @"3"
#define NEX_PARAMS_MAKE(PARAM)        [NEXNetworkRequestParamsUtil makeRequestParameters:PARAM]
#define NEX_PARAMS_NONNULL(PARAM)     [NEXNetworkRequestParamsUtil makeStringWithNoWhitespaceAndNewline:PARAM]

@interface NEXNetworkRequestParamsUtil : NSObject


#pragma mark -
#pragma mark 参数空白字符串处理
+ (NSString *)makeStringWithNoWhitespaceAndNewline:(NSString *)value;
#pragma mark 公共请求参数的处理
+ (NSMutableDictionary *)makeRequestParameters:(NSMutableDictionary *)params;


#pragma mark -
#pragma mark 网络接口 - 测试用例
+ (NSMutableDictionary *)getParametersForTest;


@end

