//
//  NEXNetworkUrlArgumentsFilter.m
//  NEXNetwork
//
//  Created by MASON on 2018/8/6.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXNetworkUrlArgumentsFilter.h"
#import "NSString+NEXNetworkUrlUtil.h"

@interface NEXNetworkUrlArgumentsFilter ()

@property NSDictionary *arguments;

@end


@implementation NEXNetworkUrlArgumentsFilter

+ (instancetype)filterWithArguments:(NSDictionary<NSString *, NSString *> *)arguments
{
    return [[self alloc] initWithArguments:arguments];
}

- (id)initWithArguments:(NSDictionary<NSString *, NSString *> *)arguments
{
    self = [super init];
    if (self) {
        _arguments = arguments;
    }
    return self;
}

- (NSString *)filterUrl:(NSString *)originUrl withRequest:(YTKBaseRequest *)request
{
    return [originUrl networkUrlStringByAppendURLParameters:_arguments];
}


@end
