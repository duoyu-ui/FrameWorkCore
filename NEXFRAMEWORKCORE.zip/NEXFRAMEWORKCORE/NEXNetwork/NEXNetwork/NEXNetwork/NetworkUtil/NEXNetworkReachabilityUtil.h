//
//  NEXNetworkReachabilityUtil.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>


#pragma mark -
#pragma mark 网络可达状态
typedef NS_ENUM(NSUInteger, NEXNetworkStatus) {
    /** 未知网络 */
    NEXNetworkStatusUnknown,
    /** 不可达的网络(未连接) */
    NEXNetworkStatusNotReachable,
    /** 手机网络2G,3G,4G */
    NEXNetworkStatusReachableViaWWAN,
    /** WIFI网络 */
    NEXNetworkStatusReachableViaWiFi
};


#pragma mark -
#pragma mark 监听网络状态变动的广播通知频段
UIKIT_EXTERN NSString * const NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY;
#pragma mark 监听网络状态变动的广播通知内容 - 字典KEY
UIKIT_EXTERN NSString * const NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY;


#pragma mark -
#pragma mark 网络状态监听的广播通知频段
typedef void(^NEXCurrentReachabilityStatusBlock)(NEXNetworkStatus networkStatus);


@interface NEXNetworkReachabilityUtil : NSObject

+ (instancetype)sharedNetworkUtilsWithCurrentReachabilityStatusBlock:(NEXCurrentReachabilityStatusBlock)currentReachabilityStatusBlock;

+ (NEXNetworkStatus)currentNetworktatus;

+ (BOOL)isNetworkAvailable;

@end

