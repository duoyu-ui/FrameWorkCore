//
//  NEXNetworkReachabilityUtil.m
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXNetworkReachabilityUtil.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

#if __has_include(<AFNetworking/AFNetworking.h>)
#import <AFNetworking/AFNetworkReachabilityManager.h>
#else
#import "AFNetworkReachabilityManager.h"
#endif

#if __has_include(<NEXProgressHUD/NEXProgressHUD.h>)
#import <NEXProgressHUD/NEXProgressHUDUtil.h>
#else
#import "NEXProgressHUDUtil.h"
#endif

#pragma mark 监听网络状态变动的广播通知频段
NSString * const NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY = @"NEXNetworkReachabilityUtilNetWorkingStatusFrequency";
#pragma mark 监听网络状态变动的广播通知内容 - 字典KEY
NSString * const NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY = @"NEXNetworkReachabilityUtilNetWorkingStatusKey";


@interface NEXNetworkReachabilityUtil ()

@property (nonatomic, strong) AFNetworkReachabilityManager *manager;

@property (nonatomic, assign) NEXNetworkStatus networktatus;

@end


@implementation NEXNetworkReachabilityUtil

#pragma mark - 网络管理单例
+ (void)load
{
    // 开启网络监听
    [[self class] currentNetworktatus];
}

#pragma mark - 网络管理单例
+ (instancetype)sharedNetworkUtilsWithCurrentReachabilityStatusBlock:(NEXCurrentReachabilityStatusBlock)currentReachabilityStatusBlock
{
    static NEXNetworkReachabilityUtil *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            // 网络请求管理单例
            _singetonInstance = [[super allocWithZone:NULL] init];
            // 网络请求Session
            _singetonInstance.manager = [AFNetworkReachabilityManager sharedManager];
            [_singetonInstance.manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
                switch (status) {
                    case AFNetworkReachabilityStatusUnknown: {
                        // 打印日志
                        NEXLog(@"未识别的网络");
                        !currentReachabilityStatusBlock?:currentReachabilityStatusBlock(NEXNetworkStatusUnknown);
                        // 网络状态
                        _singetonInstance.networktatus = NEXNetworkStatusUnknown;
                        // 发送通知
                        NSNotificationCenter * notificationCenter = [NSNotificationCenter defaultCenter];
                        [notificationCenter postNotificationName:NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY
                                                          object:self
                                                        userInfo:@{NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY:@(NEXNetworkStatusUnknown)}];
                        break;
                    }
                    case AFNetworkReachabilityStatusNotReachable: {
                        // 打印日志
                        NEXLog(@"不可达的网络(未连接)");
                        !currentReachabilityStatusBlock?:currentReachabilityStatusBlock(NEXNetworkStatusNotReachable);
                        // 网络状态
                        _singetonInstance.networktatus = NEXNetworkStatusNotReachable;
                        // 发送通知
                        NSNotificationCenter * notificationCenter = [NSNotificationCenter defaultCenter];
                        [notificationCenter postNotificationName:NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY
                                                          object:self
                                                        userInfo:@{NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY:@(NEXNetworkStatusNotReachable)}];
                        break;
                    }
                    case AFNetworkReachabilityStatusReachableViaWWAN: {
                        // 打印日志
                        NEXLog(@"2G,3G,4G...的网络");
                        !currentReachabilityStatusBlock?:currentReachabilityStatusBlock(NEXNetworkStatusReachableViaWWAN);
                        // 网络状态
                        _singetonInstance.networktatus = NEXNetworkStatusReachableViaWWAN;
                        // 发送通知
                        NSNotificationCenter * notificationCenter = [NSNotificationCenter defaultCenter];
                        [notificationCenter postNotificationName:NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY
                                                          object:self
                                                        userInfo:@{NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY:@(NEXNetworkStatusReachableViaWWAN)}];
                        break;
                    }
                    case AFNetworkReachabilityStatusReachableViaWiFi: {
                        // 打印日志
                        NEXLog(@"WIFI的网络");
                        !currentReachabilityStatusBlock?:currentReachabilityStatusBlock(NEXNetworkStatusReachableViaWiFi);
                        // 网络状态
                        _singetonInstance.networktatus = NEXNetworkStatusReachableViaWiFi;
                        // 发送通知
                        NSNotificationCenter * notificationCenter = [NSNotificationCenter defaultCenter];
                        [notificationCenter postNotificationName:NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_FREQUENCY
                                                          object:self
                                                        userInfo:@{NEX_NOTIFICATION_NETWORKING_REACHABILITY_STATUS_KEY:@(NEXNetworkStatusReachableViaWiFi)}];
                        break;
                    }
                    default: {
                        break;
                    }
                }
            }];
            [_singetonInstance.manager startMonitoring];
        }
    });
    return _singetonInstance;
}


+ (NEXNetworkStatus)currentNetworktatus
{
    return [NEXNetworkReachabilityUtil sharedNetworkUtilsWithCurrentReachabilityStatusBlock:nil].networktatus;
}

+ (BOOL)isNetworkAvailable
{
    switch ([NEXNetworkReachabilityUtil currentNetworktatus]) {
        case NEXNetworkStatusUnknown:
        case NEXNetworkStatusNotReachable: {
            return NO;
        }
        case NEXNetworkStatusReachableViaWWAN:
        case NEXNetworkStatusReachableViaWiFi: {
            return YES;
        }
    }
    return NO;
}


@end



