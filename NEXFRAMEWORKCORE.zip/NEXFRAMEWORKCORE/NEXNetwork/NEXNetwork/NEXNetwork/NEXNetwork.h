
//
//  NEXNetwork.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_NETWORK_
#define _NEX_NETWORK_

#if __has_include(<NEXNetwork/NEXNetwork.h>)

FOUNDATION_EXPORT double NEXNetworkVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXNetworkVersionString[];

#import <NEXNetwork/NEXBaseRequest.h>
#import <NEXNetwork/NEXBaseBatchRequest.h>
#import <NEXNetwork/NEXBaseChainRequest.h>

#import <NEXNetwork/NEXNetworkHTTPSessionUtil.h>
#import <NEXNetwork/NEXNetworkReachabilityUtil.h>
#import <NEXNetwork/NSString+NEXNetworkUrlUtil.h>
#import <NEXNetwork/NEXNetworkUrlArgumentsFilter.h>

#import <NEXNetwork/YTKAnimatingRequestAccessory.h>
#import <NEXNetwork/YTKBaseRequest+AnimatingAccessory.h>
#import <NEXNetwork/YTKBatchRequest+AnimatingAccessory.h>
#import <NEXNetwork/YTKChainRequest+AnimatingAccessory.h>

#import <NEXNetwork/NEXNetworkAppDelegate.h>

#else

#import "NEXBaseRequest.h"
#import "NEXBaseBatchRequest.h"
#import "NEXBaseChainRequest.h"

#import "NEXNetworkHTTPSessionUtil.h"
#import "NEXNetworkReachabilityUtil.h"
#import "NSString+NEXNetworkUrlUtil.h"
#import "NEXNetworkUrlArgumentsFilter.h"

#import "YTKAnimatingRequestAccessory.h"
#import "YTKBaseRequest+AnimatingAccessory.h"
#import "YTKBatchRequest+AnimatingAccessory.h"
#import "YTKChainRequest+AnimatingAccessory.h"

#import "NEXNetworkAppDelegate.h"

#endif /* __has_include */

#endif /* _NEX_NETWORK_ */



