//
//  ViewController.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NEXBaseRequest.h"

@interface TestRequestManager : NEXBaseRequest

@end


@interface ViewController : UIViewController


@end

