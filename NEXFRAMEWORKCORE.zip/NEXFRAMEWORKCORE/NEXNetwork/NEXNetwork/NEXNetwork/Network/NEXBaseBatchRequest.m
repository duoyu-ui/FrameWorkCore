//
//  NEXBaseBatchRequest.m
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXBaseBatchRequest.h"

@implementation NEXBaseBatchRequest

@end
