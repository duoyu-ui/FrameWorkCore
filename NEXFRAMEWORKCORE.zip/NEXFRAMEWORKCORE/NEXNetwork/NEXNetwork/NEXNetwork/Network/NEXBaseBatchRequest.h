//
//  NEXBaseBatchRequest.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#if __has_include(<YTKNetwork/YTKNetwork.h>)
#import <YTKNetwork/YTKBatchRequest.h>
#else
#import "YTKBatchRequest.h"
#endif

@interface NEXBaseBatchRequest : YTKBatchRequest

@end
