//
//  NEXBaseChainRequest.h
//  NEXNetwork
//
//  Created by MASON on 2018/8/4.
//  Copyright © 2018年 MASON. All rights reserved.
//

#if __has_include(<YTKNetwork/YTKNetwork.h>)
#import <YTKNetwork/YTKChainRequest.h>
#else
#import "YTKChainRequest.h"
#endif

@interface NEXBaseChainRequest : YTKChainRequest

@end
