//
//  NEXNetworkAppDelegate.m
//  NEXNetwork
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXNetworkAppDelegate.h"
#import "YTKNetwork.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

@implementation NEXNetworkAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NEXLog(@"网络模块 -> 加载网络模块");
    
    // 配置网络
    @try {
        // 设置基础域名开发模式
        YTKNetworkConfig *networkConfig = [YTKNetworkConfig sharedConfig];
        networkConfig.baseUrl = @"http://www.nexwork.org/restful/api";
        networkConfig.debugLogEnabled = YES;
        
        // 设置可接受的数据类型
        YTKNetworkAgent *networkAgent = [YTKNetworkAgent sharedAgent];
        NSSet *acceptableContentTypes = [NSSet setWithObjects:@"application/json",
                                         @"text/json",
                                         @"text/javascript",
                                         @"text/plain",
                                         @"text/html",
                                         @"text/css",
                                         @"image/*",
                                         @"application/x-javascript",
                                         @"keep-alive",
                                         nil];
        NSString *keypath = @"jsonResponseSerializer.acceptableContentTypes";
        [networkAgent setValue:acceptableContentTypes forKeyPath:keypath];
    } @catch (NSException *exception) {
        NEXLog(@"网络模块初始化异常 => %@", exception);
    } @finally {
        NEXLog(@"网络模块 -> 初始默认配置");
    }
    
    return YES;
}

@end

