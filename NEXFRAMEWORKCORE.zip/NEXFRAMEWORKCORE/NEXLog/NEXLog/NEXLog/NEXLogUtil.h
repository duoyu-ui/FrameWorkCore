//
//  NEXLogUtil.h
//  NEXLog
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NEXLogUtil : NSObject

+ (NSString *)getCurrentTimeStamp;

@end
