//
//  NEXLog.h
//  NEXLog
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_LOG_
#define _NEX_LOG_

#if __has_include(<NEXLog/NEXLog.h>)

FOUNDATION_EXPORT double NEXLogVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXLogVersionString[];

#import <NEXLog/NEXLogUtil.h>

/* 控件台打印 - Xcode8 */
#ifdef DEBUG
#define NEXLog(format, ...) printf("[%s] [DEBUG] %s [第%d行] => %s \n", [[NEXLogUtil getCurrentTimeStamp] UTF8String], __PRETTY_FUNCTION__, __LINE__, [[NSString stringWithFormat:format, ## __VA_ARGS__] UTF8String])
#else
#define NEXLog(__FORMAT__, ...)
#endif

#else

#import "NEXLogUtil.h"

/* 控件台打印 - Xcode8 */
#ifdef DEBUG
#define NEXLog(format, ...) printf("[%s] [DEBUG] %s [第%d行] => %s \n", [[NEXLogUtil getCurrentTimeStamp] UTF8String], __PRETTY_FUNCTION__, __LINE__, [[NSString stringWithFormat:format, ## __VA_ARGS__] UTF8String])
#else
#define NEXLog(__FORMAT__, ...)
#endif

#endif /* __has_include */


#endif /* _NEX_LOG_ */


