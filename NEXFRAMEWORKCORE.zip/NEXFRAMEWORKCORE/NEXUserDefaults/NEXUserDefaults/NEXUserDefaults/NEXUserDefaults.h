//
//  NEXUserDefaults.h
//  NEXUserDefaults
//
//  Created by MASON on 2018/8/11.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_USERDEFAULTS_H_
#define _NEX_USERDEFAULTS_H_

#if __has_include(<NEXUserDefaults/NEXUserDefaults.h>)

FOUNDATION_EXPORT double NEXUserDefaultsVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXUserDefaultsVersionString[];

#import <NEXUserDefaults/NEXSysUserDefaults.h>

#else

#import "NEXSysUserDefaults.h"

#endif /* __has_include */

#endif /* _NEX_USERDEFAULTS_H_ */

