//
//  NEXSysUserDefaults.h
//  NEXFrameworkCore
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NEXSysUserDefaults : NSObject

+ (instancetype)standardUserDefaults;

@end
