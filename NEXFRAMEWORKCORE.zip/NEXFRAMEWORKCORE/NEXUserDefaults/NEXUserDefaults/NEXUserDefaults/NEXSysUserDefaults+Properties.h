//
//  NEXSysUserDefaults+Properties.h
//  NEXSysUserDefaults
//
//  Created by MASON on 2018/8/10.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXSysUserDefaults.h"

@interface NEXSysUserDefaults (Properties)

@property (nonatomic, weak) NSString *userName;
@property (nonatomic, weak) NSNumber *userId;
@property (nonatomic) NSInteger integerValue;
@property (nonatomic) BOOL boolValue;
@property (nonatomic) float floatValue;

@end
