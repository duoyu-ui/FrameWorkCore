//
//  ViewController.m
//  NEXUserDefaults
//
//  Created by MASON on 2018/8/11.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "ViewController.h"
#import "NEXSysUserDefaults+Properties.h"


@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    NSLog(@"Should be null:");
    NSLog(@"userName: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultUserName"]);
    NSLog(@"--------------------");
    
    NSLog(@"Should be default:");
    NSLog(@"userName: %@", [NEXSysUserDefaults standardUserDefaults].userName);
    NSLog(@"--------------------");
    
    [[NSUserDefaults standardUserDefaults] setObject:@"test1" forKey:@"NSUserDefaultUserName"];
    
    NSLog(@"Should all be test1:");
    NSLog(@"userName: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultUserName"]);
    NSLog(@"userName: %@", [NEXSysUserDefaults standardUserDefaults].userName);
    NSLog(@"--------------------");
    
    [NEXSysUserDefaults standardUserDefaults].userName = @"Test 2";
    
    NSLog(@"Should all be test2:");
    NSLog(@"userName: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultUserName"]);
    NSLog(@"userName: %@", [NEXSysUserDefaults standardUserDefaults].userName);
    NSLog(@"--------------------");
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"NSUserDefaultUserName"];
    
    NSLog(@"Should all be default:");
    NSLog(@"userName: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultUserName"]);
    NSLog(@"userName: %@", [NEXSysUserDefaults standardUserDefaults].userName);
    NSLog(@"--------------------");
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    NSLog(@"Should all be 123:");
    NSLog(@"integerValue: %li", (long)[NEXSysUserDefaults standardUserDefaults].integerValue);
    NSLog(@"integerValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"integerValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"--------------------");
    
    [NEXSysUserDefaults standardUserDefaults].integerValue = 789;
    
    NSLog(@"Should all be 789:");
    NSLog(@"integerValue: %li", (long)[NEXSysUserDefaults standardUserDefaults].integerValue);
    NSLog(@"integerValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"integerValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"--------------------");
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"NSUserDefaultIntegerValue"];
    
    NSLog(@"Should all be 123:");
    NSLog(@"integerValue: %li", (long)[NEXSysUserDefaults standardUserDefaults].integerValue);
    NSLog(@"integerValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"integerValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultIntegerValue"]);
    NSLog(@"--------------------");
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    NSLog(@"Should all be 1:");
    NSLog(@"boolValue: %i", [NEXSysUserDefaults standardUserDefaults].boolValue);
    NSLog(@"boolValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"boolValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"--------------------");
    
    [NEXSysUserDefaults standardUserDefaults].boolValue = NO;
    
    NSLog(@"Should all be 0:");
    NSLog(@"boolValue: %i", [NEXSysUserDefaults standardUserDefaults].boolValue);
    NSLog(@"boolValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"boolValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"--------------------");
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"NSUserDefaultBoolValue"];
    
    NSLog(@"Should all be 1:");
    NSLog(@"boolValue: %i", [NEXSysUserDefaults standardUserDefaults].boolValue);
    NSLog(@"boolValue: %li", (long)[[NSUserDefaults standardUserDefaults] integerForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"boolValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultBoolValue"]);
    NSLog(@"--------------------");
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    NSLog(@"Should all be 12.3:");
    NSLog(@"floatValue: %f", [NEXSysUserDefaults standardUserDefaults].floatValue);
    NSLog(@"floatValue: %f", [[NSUserDefaults standardUserDefaults] floatForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"floatValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"--------------------");
    
    [NEXSysUserDefaults standardUserDefaults].floatValue = 66.6;
    
    NSLog(@"Should all be 66.6:");
    NSLog(@"floatValue: %f", [NEXSysUserDefaults standardUserDefaults].floatValue);
    NSLog(@"floatValue: %f", [[NSUserDefaults standardUserDefaults] floatForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"floatValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"--------------------");
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"NSUserDefaultFloatValue"];
    
    NSLog(@"Should all be 12.3:");
    NSLog(@"floatValue: %f", [NEXSysUserDefaults standardUserDefaults].floatValue);
    NSLog(@"floatValue: %f", [[NSUserDefaults standardUserDefaults] floatForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"floatValue OBJECT: %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"NSUserDefaultFloatValue"]);
    NSLog(@"--------------------");
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}


@end


