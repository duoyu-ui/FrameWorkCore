//
//  NEXModuleAppDelegate.h
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NEXModuleApplicationDelegate <UIApplicationDelegate>

@end

@interface NEXModuleAppDelegate : UIResponder <NEXModuleApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

