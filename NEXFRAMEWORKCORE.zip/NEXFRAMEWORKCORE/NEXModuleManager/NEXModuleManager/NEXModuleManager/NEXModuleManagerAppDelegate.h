//
//  NEXModuleManagerAppDelegate.h
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXModuleAppDelegate.h"

@interface NEXModuleManagerAppDelegate : NSObject <NEXModuleApplicationDelegate>

@end

