//
//  NEXModuleManager.h
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_MODULE_MANAGER_
#define _NEX_MODULE_MANAGER_

#if __has_include(<NEXModuleManager/NEXModuleManager.h>)

FOUNDATION_EXPORT double NEXModuleManagerVersionNumber;
FOUNDATION_EXPORT const unsigned char NEXModuleManagerVersionString[];

#import <NEXModuleManager/NEXModuleAppManager.h>
#import <NEXModuleManager/NEXModuleAppDelegate.h>
#import <NEXModuleManager/NEXModuleManagerAppDelegate.h>

#else

#import "NEXModuleAppManager.h"
#import "NEXModuleAppDelegate.h"
#import "NEXModuleManagerAppDelegate.h"

#endif /* __has_include */

#endif /* _NEX_MODULE_MANAGER_ */
