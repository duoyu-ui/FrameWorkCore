//
//  NEXModuleManagerAppDelegate.m
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXModuleManagerAppDelegate.h"

#if __has_include(<NEXLog/NEXLog.h>)
#import <NEXLog/NEXLog.h>
#else
#import "NEXLog.h"
#endif

@implementation NEXModuleManagerAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NEXLog(@"解耦模块 -> 加载解耦模块");
    
    return YES;
}

@end

