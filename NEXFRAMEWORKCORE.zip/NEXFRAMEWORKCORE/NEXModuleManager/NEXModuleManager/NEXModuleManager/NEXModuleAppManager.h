//
//  NEXModuleAppManager.h
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXModuleAppDelegate.h"

@interface NEXModuleAppManager : NSObject

+ (instancetype)sharedInstance;

- (void)loadModuleFromPlist:(NSString *)filePath;

- (NSArray<id<NEXModuleApplicationDelegate>> *) allModules;

@end

