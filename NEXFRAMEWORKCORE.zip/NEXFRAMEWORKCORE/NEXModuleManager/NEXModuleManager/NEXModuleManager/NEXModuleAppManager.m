//
//  NEXModuleAppManager.m
//  NEXModuleManager
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXModuleAppManager.h"

@interface NEXModuleAppManager ()

@property (nonatomic, strong) NSMutableArray<id<NEXModuleApplicationDelegate>> *allModuleApplication;

@end

@implementation NEXModuleAppManager

+ (instancetype)sharedInstance
{
    static NEXModuleAppManager *_singetonInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken,^{
        if (nil == _singetonInstance) {
            _singetonInstance = [[super allocWithZone:NULL] init];
        }
    });
    return _singetonInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedInstance];
}

- (id)copyWithZone:(struct _NSZone *)zone
{
    return [[self class] sharedInstance];
}

- (void)loadModuleFromPlist:(NSString *)filePath
{
    [NEXModuleAppManager sharedInstance].allModuleApplication = [NSMutableArray array];
    NSArray<NSString *> *modules = [NSArray arrayWithContentsOfFile:filePath];
    [modules enumerateObjectsUsingBlock:^(NSString * _Nonnull item, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *class_name = [NSString stringWithFormat:@"%@AppDelegate", item];
        id<NEXModuleApplicationDelegate> module = [[NSClassFromString(class_name) alloc] init];
        if (nil != module) {
            [[NEXModuleAppManager sharedInstance].allModuleApplication addObject:module];
        }
    }];
}

- (NSArray<id<NEXModuleApplicationDelegate>> *) allModules
{
    if (self.allModuleApplication && self.allModuleApplication.count > 0) {
        return [NSArray arrayWithArray:self.allModuleApplication];
    }
    return [NSArray array];
}

@end


