//
//  NEXTabFirstDemoViewController.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/7/23.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabFirstDemoViewController.h"

@implementation TestRequestManager

@end


@interface NEXTabFirstDemoViewController ()
@property (nonatomic, strong) TestRequestManager *requestSession;
@property (nonatomic, strong) UITextView *textView;
@end


@implementation NEXTabFirstDemoViewController

- (void)viewDidLoadWithNetworkingStatus
{
    self.title = @"网络模块测试";
    
    // 1、缓存并获取数据
    UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    [button1 setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width-40, 50)];
    [button1 setCenter:CGPointMake(self.view.center.x, 50)];
    [button1 setTitle:@"缓存并获取数据" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button1 setBackgroundColor:[UIColor lightGrayColor]];
    [button1 addTarget:self action:@selector(pressNetworkButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    // 2、显示加载数据
    UITextView * textView = [[UITextView alloc] init];
    [textView setText:@"空白数据"];
    [textView setFrame:CGRectMake(CGRectGetMinX(button1.frame),
                                  CGRectGetMaxY(button1.frame)+20.0f,
                                  [UIScreen mainScreen].bounds.size.width-CGRectGetMinX(button1.frame)*2.0f,
                                  [UIScreen mainScreen].bounds.size.height-CGRectGetMaxY(button1.frame)-160.0f)];
    [textView setTextColor:[UIColor blackColor]];
    [textView setBackgroundColor:[UIColor lightTextColor]];
    [textView.layer setBorderWidth:1.0];
    [textView.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.view addSubview:textView];
    [self setTextView:textView];
    
    self.requestSession = [[TestRequestManager alloc] init];
    
    [self pressNetworkButton:nil];
}

- (void)updateTextViewWithLog:(NSString*)log
{
    self.textView.text = log;
}


// 缓存并获取数据
- (void)pressNetworkButton:(UIButton *)button
{
    // 请求地址与参数
    NSString *url = @"http://23.225.141.18:8080/api/by/f_b_getSiteBonusType";
    NSDictionary *parameters = @{ @"appversion":@"1.0.0", @"app_type":@"", @"local_token":@"1", @"site_id":@"1" };
    
#if 0
    
    // 方式一：集约型网络请求数据
    {
        [NEXNetworkHTTPSessionUtil POST:url parameters:parameters responseCache:^(id responseCache) {
            
            NEXLog(@"集约型网络 -> 读取缓存数据 => %@", responseCache);
            
        } success:^(id responseObject) {
            
            NEXLog(@"集约型网络 -> 请求接口数据 -> %@", responseObject);
            
            [self updateTextViewWithLog:[NSString stringWithFormat:@"接口数据 = %@", responseObject]];
            
        } failure:^(NSError *error) {
            
            NEXLog(@"%@", error);
            
        } showMessage:@"集约网络请求数据" showProgressHUD:YES isHideErrorMessage:NO];
    }
    
#elif 1
    
    // 方式二：离散型网络请求数据
    {
        self.requestSession.url = url;
        self.requestSession.parameters = parameters;
        self.requestSession.animatingView = self.view;
        self.requestSession.animatingText = @"离散网络请求数据";
        
        // 每次读缓存，同时从接口中获取最新数据
        if ([self.requestSession loadCacheWithError:nil]) {
            
            NEXLog(@"离散型网络 -> 读取缓存数据 => %@", self.requestSession.responseJSONObject);
            
            [self updateTextViewWithLog:[NSString stringWithFormat:@"缓存数据 = %@", self.requestSession.responseJSONObject]];
        }
        
        // 从接口获取数据
        [self.requestSession startWithCompletionBlockWithSuccess:^(__kindof YTKBaseRequest * _Nonnull request) {
            
            // NEXLog(@"responseData->%@", request.responseData);
            // NEXLog(@"responseString->%@", request.responseString);
            // NEXLog(@"responseObject->%@", request.responseObject);
            
            NEXLog(@"离散型网络 -> 请求接口数据 -> %@", request.responseJSONObject);
            
            [self updateTextViewWithLog:[NSString stringWithFormat:@"接口数据 = %@", self.requestSession.responseJSONObject]];
            
        } failure:^(__kindof YTKBaseRequest * _Nonnull request) {
            
            NEXLog(@"%@", self.requestSession.responseJSONObject);
            
        }];
    }
    
#endif
    
}


@end


