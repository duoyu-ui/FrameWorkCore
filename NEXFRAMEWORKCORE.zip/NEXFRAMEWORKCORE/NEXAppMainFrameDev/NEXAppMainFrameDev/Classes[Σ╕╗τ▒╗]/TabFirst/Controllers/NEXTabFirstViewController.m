//
//  NEXTabFirstViewController.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/26.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabFirstViewController.h"
#import "NEXTabFirstTableViewCell.h"
#import "NEXTabFirstCellModel.h"
#import "NEXTabFirstDemoViewController.h"


@implementation NEXTabFirstViewController

#pragma mark 事件处理 - 导航栏右按钮事件
- (void)pressNavigationBarRightButtonItem:(id)sender
{
    [super pressNavigationBarRightButtonItem:sender];
    
    NEXTabFirstDemoViewController *viewController = [[NEXTabFirstDemoViewController alloc] init];
    [self.navigationController pushViewController:viewController animated:YES];
}


#pragma mark -
#pragma mark 视图生命周期（初始化）
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.hasPage = YES;
        self.hasTableViewRefresh = YES;
        self.requestMethod = NEXRequestMethodPOST;
    }
    return self;
}


#pragma mark 视图生命周期（加载视图）
- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

#pragma mark 注册UITableViewCell
- (void)tableViewRefreshRegisterClass:(UITableView *)tableView
{
    [self.tableViewRefresh registerClass:[NEXTabFirstTableViewCell class] forCellReuseIdentifier:CELL_IDENTIFIER_TAB_FIRST_TABLEVIEW];
}


#pragma mark -
#pragma mark 设置导航栏右边按钮类型
- (NEXNavBarButtonItemType)prefersNavigationBarRightButtonItemType
{
    return NEXNavBarButtonItemTypeCustom;
}

#pragma mark 设置导航栏右边按钮控件标题
- (NSString *)prefersNavigationBarRightButtonItemTitle
{
    return @"网络";
}


#pragma mark -
#pragma mark 请求地址（子类继承实现）
- (NSString *)getRequestURLString
{
    return @"http://23.225.141.18:8080/api/fp/f_f_getRecentSlider";
}

#pragma mark 请求参数（子类继承实现）
- (NSMutableDictionary *)getRequestParamerter
{
    return @{ @"appversion":@"1.0.0", @"app_type":@"", @"local_token":@"1", @"site_id":@"1", @"slider_type":@"0" }.mutableCopy;
}

#pragma mark 请求网络数据或加载缓存
- (NSMutableArray *)loadNetworkDataOrCacheData:(id)responseDataOrCacheData isCacheData:(BOOL)isCacheData
{
    NSDictionary *resultData = (NSDictionary *)responseDataOrCacheData;
    NEXLog(@"%@",resultData);
    
    WEAKSELF(weakSelf);
    NSInteger status = [[resultData objectForKey:@"code"] integerValue];
    NSArray *dataArray = [resultData objectForKey:@"data"];
    if (![NEXDevSysUtil validateResultCodeIsSuccess:status] || [NEXDevSysUtil validateObjectIsNull:dataArray]) {
        weakSelf.tableDataRefresh = @[].mutableCopy;
        return weakSelf.tableDataRefresh;
    }
    
    NSMutableArray <NEXTabFirstCellModel *> *modelArray = [NSMutableArray array];
    [dataArray enumerateObjectsUsingBlock:^(NSDictionary*  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NEXTabFirstCellModel *model = [NEXTabFirstCellModel mj_objectWithKeyValues:obj];
        [modelArray addObject:model];
    }];
    
    if (0 == self.offset || isCacheData) {
        weakSelf.tableDataRefresh = [NSMutableArray array];
        [weakSelf.tableDataRefresh addObjectsFromArray:modelArray];
    }else{
        [weakSelf.tableDataRefresh addObjectsFromArray:modelArray];
    }
    
    return self.tableDataRefresh;
}


#pragma mark - TableView Data Source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.tableDataRefresh && self.tableDataRefresh.count > 0) {
        
        return self.tableDataRefresh.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NEXTabFirstTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CELL_IDENTIFIER_TAB_FIRST_TABLEVIEW];
    if (!cell) {
        cell = [[NEXTabFirstTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CELL_IDENTIFIER_TAB_FIRST_TABLEVIEW];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.model = self.tableDataRefresh[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NEX_AUTOSIZING_WIDTH(120.0f);
}


@end


