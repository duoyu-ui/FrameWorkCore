//
//  NEXTabFirstDemoViewController.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/7/23.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXBaseCommonViewController.h"

@interface TestRequestManager : NEXBaseRequest

@end

@interface NEXTabFirstDemoViewController : NEXBaseCommonViewController

@end
