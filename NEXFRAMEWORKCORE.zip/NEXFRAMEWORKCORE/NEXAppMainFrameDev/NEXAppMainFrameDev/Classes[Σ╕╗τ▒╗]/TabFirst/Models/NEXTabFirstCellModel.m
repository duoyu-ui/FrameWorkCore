//
//  NEXTabFirstCellModel.m
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabFirstCellModel.h"

@implementation NEXTabFirstCellModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"index_id" : @"id",
             @"slider_content" : @"slider_title"
             };
}

@end
