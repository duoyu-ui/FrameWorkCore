//
//  NEXTabFirstCellModel.h
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NEXTabFirstCellModel : NSObject

@property (nonatomic,copy) NSString *img_url;
@property (nonatomic,copy) NSString *slider_title;
@property (nonatomic,copy) NSNumber *add_time;
@property (nonatomic,copy) NSNumber *index_id;
@property (nonatomic,copy) NSString *slider_content;

@end
