//
//  NEXTabFirstTableViewCell.m
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabFirstTableViewCell.h"
#import "NEXTabFirstCellModel.h"

// Cell Identifier
NSString * const CELL_IDENTIFIER_TAB_FIRST_TABLEVIEW = @"NEXTabFirstTableViewCellIdentifier";


@interface NEXTabFirstTableViewCell()
/**
 * 根容器组件
 */
@property (nonatomic, strong) UIView *rootContainerView;
/**
 * 公共容器
 */
@property (nonatomic, strong) UIView *publicContainerView;
/**
 * 图片控件
 */
@property (nonatomic, strong) UIImageView *adImageView;
/**
 * 分割线控件
 */
@property (nonatomic, strong) UIView *separatorLineView;

@end

@implementation NEXTabFirstTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self createViewAtuoLayout];
    }
    return self;
}


#pragma mark - 创建子控件
- (void)createViewAtuoLayout
{
    CGFloat margin = NEX_AUTOSIZING_MARGIN(MARGIN);
    
    // 根容器
    UIView *rootContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_TABLEVIEW_BACK_VIEW_BACKGROUND_DEFAULT];
        [self.contentView insertSubview:view atIndex:0];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@0.0f);
            make.top.equalTo(@0.0f);
            make.right.equalTo(@0.0f);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(0);
        }];
        
        view;
    });
    self.rootContainerView = rootContainerView;
    self.rootContainerView.mas_key = @"rootContainerView";
    
    // 公共容器
    UIView *publicContainerView = ({
        UIView *view = [[UIView alloc] init];
        [view.layer setMasksToBounds:YES];
        [view setBackgroundColor:COLOR_SYSTEM_MAIN_UI_BACKGROUND_FRONT_DEFAULT];
        [rootContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(rootContainerView.mas_left).offset(0.0f);
            make.top.equalTo(rootContainerView.mas_top).offset(0.0f);
            make.right.equalTo(rootContainerView.mas_right).offset(0.0f);
            make.bottom.equalTo(rootContainerView.mas_bottom).offset(0.0f);
        }];
        
        view;
    });
    self.publicContainerView = publicContainerView;
    self.publicContainerView.mas_key = @"publicContainerView";
    
    // 广告图片
    UIImageView *adImageView = ({
        UIImageView *imageView = [UIImageView new];
        [publicContainerView addSubview:imageView];

        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(publicContainerView.mas_top).offset(margin*1.0f);
            make.left.equalTo(publicContainerView.mas_left).offset(margin*1.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(-margin*1.0f);
            make.height.mas_equalTo(NEX_AUTOSIZING_WIDTH(120.0f));
        }];
        
        imageView;
    });
    self.adImageView = adImageView;
    self.adImageView.mas_key = [NSString stringWithFormat:@"adImageView"];
    
    // 分割线
    UIView *separatorLineView = ({
        UIView *view = [[UIView alloc] init];
        [view setBackgroundColor:COLOR_TABLEVIEW_SEPARATOR_LINE_DEFAULT];
        [publicContainerView addSubview:view];
        
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(adImageView.mas_bottom).offset(margin*1.0f);
            make.left.equalTo(publicContainerView.mas_left).offset(0.0f);
            make.right.equalTo(publicContainerView.mas_right).offset(0.0f);
            make.height.equalTo(@(1.0f));
        }];
        
        view;
    });
    self.separatorLineView = separatorLineView;
    self.separatorLineView.mas_key = @"separatorLineView";
    
    // 约束的完整性
    [publicContainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(separatorLineView.mas_bottom).offset(0.0f).priority(749);
    }];
    
}


#pragma mark - 设置数据模型
- (void)setModel:(NEXTabFirstCellModel *)model
{
    // 类型安全检查
    if (![model isKindOfClass:[NEXTabFirstCellModel class]]) {
        return;
    }
    
    // 数据赋值
    _model = model;
    
    // 广告图片
    [self.adImageView sd_setImageWithURL:[NSURL URLWithString:model.img_url] placeholderImage:nil];
}


@end



