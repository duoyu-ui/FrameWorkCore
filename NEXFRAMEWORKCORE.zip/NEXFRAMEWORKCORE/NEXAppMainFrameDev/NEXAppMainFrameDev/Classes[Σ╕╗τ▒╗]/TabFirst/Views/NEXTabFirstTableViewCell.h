//
//  NEXTabFirstTableViewCell.h
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NEXTabFirstCellModel;


UIKIT_EXTERN NSString * const CELL_IDENTIFIER_TAB_FIRST_TABLEVIEW;


@interface NEXTabFirstTableViewCell : UITableViewCell

/**
 * 数据模型
 */
@property (nonatomic, strong) NEXTabFirstCellModel *model;


@end


