//
//  NEXTabSecondViewController.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/26.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabSecondViewController.h"

@interface NEXTabSecondViewController ()

@end

@implementation NEXTabSecondViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
