//
//  NEXRootViewController.m
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXRootViewController.h"
#import "NEXTabFirstViewController.h"
#import "NEXTabSecondViewController.h"
#import "NEXTabThirdViewController.h"
#import "NEXTabFourthViewController.h"

@interface NEXRootViewController ()

@end

@implementation NEXRootViewController

#pragma mark 添加子控制器
- (void)addChildControllers
{
    // 首页
    [self addChildNavigationController:[NEXNavigationController class]
                    rootViewController:[NEXTabFirstViewController class]
                       navigationTitle:NAVIGATION_BAR_TITLE_FIRST
                       tabBarItemTitle:TAB_BAR_ITEM_NAME_FIRST
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_FIRST_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_FIRST_SELECT
                     tabBarItemEnabled:YES];
    
    // 订单
    [self addChildNavigationController:[NEXNavigationController class]
                    rootViewController:[NEXTabSecondViewController class]
                       navigationTitle:NAVIGATION_BAR_TITLE_SECOND
                       tabBarItemTitle:TAB_BAR_ITEM_NAME_SECOND
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_SECOND_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_SECOND_SELECT
                     tabBarItemEnabled:YES];
    
    // 发现
    [self addChildNavigationController:[NEXNavigationController class]
                    rootViewController:[NEXTabThirdViewController class]
                       navigationTitle:NAVIGATION_BAR_TITLE_THIRD
                       tabBarItemTitle:TAB_BAR_ITEM_NAME_THIRD
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_THIRD_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_THIRD_SELECT
                     tabBarItemEnabled:YES];
    
    // 我的
    [self addChildNavigationController:[NEXNavigationController class]
                    rootViewController:[NEXTabFourthViewController class]
                       navigationTitle:NAVIGATION_BAR_TITLE_FOURTH
                       tabBarItemTitle:TAB_BAR_ITEM_NAME_FOURTH
                 tabBarNormalImageName:ICON_TAB_BAR_ITEM_FOURTH_NORMAL
                 tabBarSelectImageName:ICON_TAB_BAR_ITEM_FOURTH_SELECT
                     tabBarItemEnabled:YES];
}

#pragma mark -
#pragma mark 通过设置返回值来禁止某个UIViewController能否被选中
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    return YES;
}

#pragma mark 选中Tab项时被调用（在这里做某些操作：如隐藏状态栏，导航栏什么的）
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NEXLog(@"%@", viewController.title);
}

@end



