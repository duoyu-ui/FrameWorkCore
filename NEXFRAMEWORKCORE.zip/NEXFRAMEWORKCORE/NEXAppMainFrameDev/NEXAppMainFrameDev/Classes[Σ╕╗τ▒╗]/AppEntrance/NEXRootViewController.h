//
//  NEXRootViewController.h
//  FINDIOSPROJECT
//
//  Created by MASON on 2018/6/25.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXTabBarController.h"

@interface NEXRootViewController : NEXTabBarController


@end

