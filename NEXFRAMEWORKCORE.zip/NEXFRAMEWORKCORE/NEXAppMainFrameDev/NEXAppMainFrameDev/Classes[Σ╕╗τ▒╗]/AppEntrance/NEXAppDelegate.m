//
//  NEXAppDelegate.m
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/3.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXAppDelegate.h"
#import "NEXRootViewController.h"

@interface NEXAppDelegate ()

@end

@implementation NEXAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [super application:application didFinishLaunchingWithOptions:launchOptions];
    

    return YES;
}


@end
