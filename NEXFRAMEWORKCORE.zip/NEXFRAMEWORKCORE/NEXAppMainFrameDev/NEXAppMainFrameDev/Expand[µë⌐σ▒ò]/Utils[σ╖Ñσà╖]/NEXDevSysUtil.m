//
//  NEXDevSysUtil.m
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXDevSysUtil.h"

@implementation NEXDevSysUtil

#pragma mark-
#pragma mark 验证请求数据是滞成功
+ (BOOL)validateResultCodeIsSuccess:(NSInteger)resultCode
{
    if (0 == resultCode) {
        return YES;
    }
    return NO;
}

@end
