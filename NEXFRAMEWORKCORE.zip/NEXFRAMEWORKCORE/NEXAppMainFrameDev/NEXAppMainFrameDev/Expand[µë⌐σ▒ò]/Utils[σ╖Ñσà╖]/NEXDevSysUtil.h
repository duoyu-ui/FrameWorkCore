//
//  NEXDevSysUtil.h
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import "NEXSysUtil.h"

@interface NEXDevSysUtil : NEXSysUtil


#pragma mark-
#pragma mark 验证请求数据是滞成功
+ (BOOL)validateResultCodeIsSuccess:(NSInteger)resultCode;


@end
