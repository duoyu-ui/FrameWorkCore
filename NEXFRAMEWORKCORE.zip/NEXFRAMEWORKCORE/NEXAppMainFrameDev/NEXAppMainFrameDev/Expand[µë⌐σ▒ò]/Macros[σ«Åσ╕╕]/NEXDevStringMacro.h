//
//  NEXDevStringMacro.h
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_DEV_STRING_MACRO_H_
#define _NEX_DEV_STRING_MACRO_H_


#pragma mark - 标签栏标题 - 首页/消息/广场/我的
#define TAB_BAR_ITEM_NAME_FIRST                                                  @"首页"
#define TAB_BAR_ITEM_NAME_SECOND                                                 @"订单"
#define TAB_BAR_ITEM_NAME_THIRD                                                  @"发现"
#define TAB_BAR_ITEM_NAME_FOURTH                                                 @"我的"


#pragma mark - 导航栏标题 - 首页/消息/广场/我的
#define NAVIGATION_BAR_TITLE_FIRST                                               @"首页"
#define NAVIGATION_BAR_TITLE_SECOND                                              @"订单"
#define NAVIGATION_BAR_TITLE_THIRD                                               @"发现"
#define NAVIGATION_BAR_TITLE_FOURTH                                              @"我的"


#endif /* _NEX_DEV_STRING_MACRO_H_ */
