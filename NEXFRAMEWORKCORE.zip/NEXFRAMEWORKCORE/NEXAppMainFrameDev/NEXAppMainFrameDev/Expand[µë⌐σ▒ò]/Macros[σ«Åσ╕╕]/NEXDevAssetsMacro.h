//
//  NEXDevAssetsMacro.h
//  NEXAppMainFrameDev
//
//  Created by MASON on 2018/8/7.
//  Copyright © 2018年 MASON. All rights reserved.
//

#ifndef _NEX_DEV_ASSETS_MACRO_H_
#define _NEX_DEV_ASSETS_MACRO_H_


#pragma mark -
#pragma mark 图标：标签栏按钮
#define ICON_TAB_BAR_ITEM_FIRST_NORMAL                              @"icon_tabbar_foot_home"
#define ICON_TAB_BAR_ITEM_FIRST_SELECT                              @"icon_tabbar_foot_home_selected"
#define ICON_TAB_BAR_ITEM_SECOND_NORMAL                             @"icon_tabbar_foot_order"
#define ICON_TAB_BAR_ITEM_SECOND_SELECT                             @"icon_tabbar_foot_order_selected"
#define ICON_TAB_BAR_ITEM_THIRD_NORMAL                              @"icon_tabbar_foot_find"
#define ICON_TAB_BAR_ITEM_THIRD_SELECT                              @"icon_tabbar_foot_find_selected"
#define ICON_TAB_BAR_ITEM_FOURTH_NORMAL                             @"icon_tabbar_foot_mine"
#define ICON_TAB_BAR_ITEM_FOURTH_SELECT                             @"icon_tabbar_foot_mine_selected"


#endif /* _NEX_DEV_ASSETS_MACRO_H_ */

