//
//  DemoListViewController.h
//  NEXRouter
//
//  Created by MASON on 2018/8/13.
//  Copyright © 2018年 MASON. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef UIViewController *(^ViewControllerHandler)(void);

@interface DemoListViewController : UIViewController

+ (void)registerWithTitle:(NSString *)title handler:(ViewControllerHandler)handler;

@end

